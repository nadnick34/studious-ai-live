-- Studious AI – ADDITIVE schema only
-- Safe to run more than once.
-- Does NOT drop tables, does NOT delete rows.

-- Classes
create table if not exists public.classes (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  code text not null default '',
  subject text not null default '',
  created_at timestamptz not null default now(),
  last_accessed timestamptz not null default now(),
  archived boolean not null default false,
  school_name text,
  semester text,
  professor_name text,
  professor_insight text,
  textbook text,
  textbook_author text,
  schedule_days text,
  schedule_time text,
  syllabus_file text,
  misc_notes text
);

-- Study sets (notes, quiz, audio script, flashcards as JSON)
create table if not exists public.study_sets (
  id text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  class_id text not null,
  name text not null,
  created_at timestamptz not null default now(),
  source_files jsonb not null default '[]'::jsonb,
  notes jsonb not null default '{}'::jsonb,
  audio_script text not null default '',
  quiz jsonb not null default '[]'::jsonb,
  flashcards jsonb not null default '[]'::jsonb,
  focus_prompt text
);

-- In case an older table exists without a column, add it (no-op if present)
alter table public.classes add column if not exists archived boolean not null default false;
alter table public.classes add column if not exists school_name text;
alter table public.classes add column if not exists semester text;
alter table public.classes add column if not exists professor_name text;
alter table public.classes add column if not exists professor_insight text;
alter table public.classes add column if not exists textbook text;
alter table public.classes add column if not exists textbook_author text;
alter table public.classes add column if not exists schedule_days text;
alter table public.classes add column if not exists schedule_time text;
alter table public.classes add column if not exists syllabus_file text;
alter table public.classes add column if not exists misc_notes text;
alter table public.study_sets add column if not exists focus_prompt text;
alter table public.study_sets add column if not exists flashcards jsonb not null default '[]'::jsonb;

alter table public.classes enable row level security;
alter table public.study_sets enable row level security;

-- Policies: create only if missing
do $$
begin
  if not exists (select 1 from pg_policies where policyname = 'classes_select_own') then
    create policy classes_select_own on public.classes for select
      using (auth.uid() = user_id);
  end if;
  if not exists (select 1 from pg_policies where policyname = 'classes_insert_own') then
    create policy classes_insert_own on public.classes for insert
      with check (auth.uid() = user_id);
  end if;
  if not exists (select 1 from pg_policies where policyname = 'classes_update_own') then
    create policy classes_update_own on public.classes for update
      using (auth.uid() = user_id);
  end if;
  if not exists (select 1 from pg_policies where policyname = 'classes_delete_own') then
    create policy classes_delete_own on public.classes for delete
      using (auth.uid() = user_id);
  end if;

  if not exists (select 1 from pg_policies where policyname = 'sets_select_own') then
    create policy sets_select_own on public.study_sets for select
      using (auth.uid() = user_id);
  end if;
  if not exists (select 1 from pg_policies where policyname = 'sets_insert_own') then
    create policy sets_insert_own on public.study_sets for insert
      with check (auth.uid() = user_id);
  end if;
  if not exists (select 1 from pg_policies where policyname = 'sets_update_own') then
    create policy sets_update_own on public.study_sets for update
      using (auth.uid() = user_id);
  end if;
  if not exists (select 1 from pg_policies where policyname = 'sets_delete_own') then
    create policy sets_delete_own on public.study_sets for delete
      using (auth.uid() = user_id);
  end if;
end $$;

create index if not exists classes_user_id_idx on public.classes (user_id);
create index if not exists study_sets_user_id_idx on public.study_sets (user_id);
create index if not exists study_sets_class_id_idx on public.study_sets (class_id);

-- Profile preferences (colors, logo, photo) — additive only
alter table public.profiles add column if not exists phone text;
alter table public.profiles add column if not exists sms_alerts boolean not null default false;
alter table public.profiles add column if not exists school_select text;
alter table public.profiles add column if not exists account_role text;
alter table public.profiles add column if not exists edition text;
alter table public.profiles add column if not exists avatar_data_url text;
alter table public.profiles add column if not exists brand_json jsonb;
