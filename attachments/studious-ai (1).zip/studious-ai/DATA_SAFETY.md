# How Studious AI avoids wiping user work

## Rule
Code updates change the website. They do **not** erase classes, notes, quizzes, or accounts.

## Two layers
1. **Browser localStorage** — always kept as a backup on that device.
2. **Supabase (when configured)** — cloud copy so another device can load the same work.

On sign-in we **merge** local + cloud (upsert by id). We do not delete cloud rows as part of a deploy.

## Safe schema changes
- `CREATE TABLE IF NOT EXISTS`
- `ADD COLUMN IF NOT EXISTS`
- Never `DROP TABLE` / `DELETE FROM` in deploy scripts

## What you must not do
- Create a brand-new empty Supabase project and point production at it
- Run SQL that drops `classes` or `study_sets`
- Clear a user’s site data and expect local-only work to come back (without cloud)

## Feature updates
`git push` to Vercel only ships new UI/prompts. Existing database rows stay.
