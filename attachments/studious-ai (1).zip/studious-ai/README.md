# Studious AI – Student Edition

**Your masterclass for every class.**

A Next.js app that turns class notes, PDFs, images, and recordings into comprehensive study notes, audio lectures, and interactive quizzes.

---

## Quick Start (on your computer)

```bash
cd studious-ai
npm install
npm run dev
```

Open http://localhost:3000  
Sign in with any email/password (demo mode).

---

## Publish Online (so your son can use it)

### Step 1 – Create a free Vercel account
1. Go to https://vercel.com
2. Click **Sign Up**
3. Choose **Continue with GitHub** (easiest) or email

### Step 2 – Put the code on GitHub (recommended)
1. Create a new **private** repository on GitHub named `studious-ai`
2. On your computer, open a terminal in the `studious-ai` folder and run:

```bash
git init
git add .
git commit -m "Studious AI Student Edition"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/studious-ai.git
git push -u origin main
```

(Replace `YOUR_USERNAME` with your GitHub username.)

### Step 3 – Deploy to Vercel
1. In Vercel, click **Add New… → Project**
2. Import the `studious-ai` GitHub repository
3. Leave all settings at the defaults
4. Click **Deploy**
5. Wait 1–2 minutes

You will get a live URL that looks like:
```
https://studious-ai-xxxxx.vercel.app
```

### Step 4 – Share the link
Send that URL to your son. He can open it on phone, tablet, or laptop.

---

## Optional: Enable real AI generation

By default the app uses a high-quality mock so everything works without keys.

To use real AI:

1. In Vercel → your project → **Settings → Environment Variables**
2. Add one of these:
   - Name: `GROK_API_KEY`   Value: your xAI key
   - **or** Name: `OPENAI_API_KEY`   Value: your OpenAI key
3. Redeploy (Deployments → … → Redeploy)

Locally, copy `.env.example` to `.env.local` and add the same key, then restart `npm run dev`.

---

## What works today

- Login (demo)
- Dashboard + create classes
- Class history (Date/Time, Name, PDF, Audio, Quiz)
- Upload materials → generate study package
- Study notes with sections + Other Resources
- Audio lecture player + script
- Interactive quiz with feedback and score
- Combine chapters for midterm/final (UI)
- Data saved in the browser (localStorage)

---

## Project structure

```
src/
  app/
    page.tsx                  Login
    dashboard/                Home
    class/[id]/              Class detail + history
    class/[id]/upload/       Upload & generate
    class/[id]/set/[setId]/ Study notes / audio / quiz
    api/generate/             AI generation endpoint
  components/                 Sidebar, AppShell, Button
  lib/                        store + prompts
  types/                      TypeScript types
```

---

## Tech

- Next.js 16 (App Router)
- TypeScript
- Tailwind CSS 4
- localStorage for persistence (MVP)
