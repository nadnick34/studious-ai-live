"use client";

import type { Class, StudySet, User, AppState } from "@/types";
import { getSessionUser } from "@/lib/auth";
import { upsertClassCloud, upsertSetCloud } from "@/lib/sync";
export type { Class, StudySet, User, AppState };

const STORAGE_KEY = "studious-ai-v3";

function uid(prefix: string) {
  return prefix + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function seedForUser(userId: string): { classes: Class[]; studySets: StudySet[] } {
  // Only seed demo content for the built-in sample student
  if (userId !== "student-1") {
    return { classes: [], studySets: [] };
  }

  const classes: Class[] = [
    {
      id: "c1",
      userId,
      name: "Principles of Biology",
      code: "BIOL 1543",
      subject: "Biology",
      createdAt: "2026-08-01T10:00:00Z",
      lastAccessed: "2026-08-15T14:00:00Z",
    },
    {
      id: "c2",
      userId,
      name: "University Chemistry I",
      code: "CHEM 1103",
      subject: "Chemistry",
      createdAt: "2026-08-02T10:00:00Z",
      lastAccessed: "2026-08-14T09:00:00Z",
    },
    {
      id: "c3",
      userId,
      name: "Calculus I",
      code: "MATH 2554",
      subject: "Mathematics",
      createdAt: "2026-08-03T10:00:00Z",
      lastAccessed: "2026-08-12T16:00:00Z",
    },
  ];

  const studySets: StudySet[] = [
    {
      id: "s1",
      classId: "c1",
      userId,
      name: "Chapters 1–3",
      createdAt: "2026-08-12T14:14:00Z",
      sourceFiles: ["Campbell_Ch1-3.pdf", "Lecture_Week1-2.pdf"],
      notes: {
        title: "BIOL 1543 – Principles of Biology",
        subtitle: "Chapters 1–3 · University of Arkansas",
        sections: [
          {
            heading: "1. The Scientific Method",
            bullets: [
              "Observation – noticing a phenomenon or pattern in nature",
              "Hypothesis – a testable, falsifiable explanation",
              "Experiment – controlled test with independent & dependent variables",
              "Analysis – interpret data; accept, reject, or refine the hypothesis",
              "Theory – a well-supported explanation that has withstood repeated testing",
            ],
            reference: "Campbell Biology, Ch. 1",
          },
          {
            heading: "2. Characteristics of Living Things",
            bullets: [
              "Cellular organization",
              "Metabolism (energy processing)",
              "Homeostasis",
              "Growth and development",
              "Reproduction",
              "Response to stimuli",
              "Evolutionary adaptation",
            ],
          },
          {
            heading: "3. Levels of Biological Organization",
            bullets: [
              "Atom → Molecule → Organelle → Cell → Tissue → Organ → Organ System → Organism",
              "Population → Community → Ecosystem → Biosphere",
            ],
            reference: "Class lecture notes, Week 2",
          },
        ],
        otherResources: [
          { title: "Khan Academy – Introduction to Biology (YouTube)" },
          { title: "Crash Course Biology – Scientific Method" },
          { title: "OpenStax Biology 2e, Chapter 1" },
        ],
      },
      audioScript: `Welcome to this Studious AI review of Chapters 1 through 3 of Principles of Biology.

We begin with the scientific method. Science starts with careful observation of the natural world. From those observations we form a hypothesis — a testable and falsifiable explanation. We then design controlled experiments, collect data, and analyze the results. Only after repeated testing and confirmation does an idea rise to the level of a scientific theory.

Living things share several key characteristics: cellular organization, metabolism, homeostasis, growth and development, reproduction, response to stimuli, and evolutionary adaptation.

Finally, biology is organized across many levels — from atoms and molecules up through cells, tissues, organs, organisms, populations, communities, ecosystems, and the biosphere.

Keep these foundations clear. They will support everything that follows in this course.`,
      quiz: [
        {
          id: "q1",
          question: "Which of the following is a key characteristic of a scientific hypothesis?",
          options: [
            "It must be proven true",
            "It must be testable and falsifiable",
            "It is the same as a theory",
            "It cannot be revised",
          ],
          correctIndex: 1,
          explanation: "A hypothesis must be testable and capable of being shown false.",
        },
        {
          id: "q2",
          question: "Homeostasis refers to an organism’s ability to:",
          options: [
            "Reproduce rapidly",
            "Maintain a stable internal environment",
            "Evolve over generations",
            "Respond only to external stimuli",
          ],
          correctIndex: 1,
        },
        {
          id: "q3",
          question: "Which sequence correctly shows levels of biological organization from smallest to largest?",
          options: [
            "Cell → Atom → Organism → Ecosystem",
            "Atom → Molecule → Cell → Organism",
            "Organism → Tissue → Cell → Molecule",
            "Ecosystem → Population → Cell → Atom",
          ],
          correctIndex: 1,
        },
        {
          id: "q4",
          question: "A scientific theory is best described as:",
          options: [
            "An untested idea",
            "A guess about the natural world",
            "A well-supported explanation that has withstood repeated testing",
            "A single experiment’s conclusion",
          ],
          correctIndex: 2,
        },
      ],
      flashcards: [
        { id: "f1", term: "Hypothesis", definition: "A testable, falsifiable explanation for an observation." },
        { id: "f2", term: "Theory", definition: "A well-supported explanation that has withstood repeated testing." },
        { id: "f3", term: "Homeostasis", definition: "An organism’s ability to maintain a stable internal environment." },
        { id: "f4", term: "Metabolism", definition: "The sum of chemical processes that process energy in living things." },
        { id: "f5", term: "Cell", definition: "The basic unit of structure and function in living organisms." },
        { id: "f6", term: "Biosphere", definition: "All ecosystems on Earth; the highest level of biological organization." },
      ],
    },
  ];

  return { classes, studySets };
}

type StoredState = {
  classes: Class[];
  studySets: StudySet[];
};

function loadAll(): StoredState {
  if (typeof window === "undefined") {
    return { classes: [], studySets: [] };
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as StoredState;
      return {
        classes: Array.isArray(parsed.classes) ? parsed.classes : [],
        studySets: (Array.isArray(parsed.studySets) ? parsed.studySets : []).map(normalizeStudySet),
      };
    }
  } catch {
    /* ignore */
  }
  return { classes: [], studySets: [] };
}

function saveAll(state: StoredState) {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function normalizeStudySet(s: StudySet): StudySet {
  return {
    ...s,
    flashcards: Array.isArray(s.flashcards) ? s.flashcards : [],
    quiz: Array.isArray(s.quiz) ? s.quiz : [],
    sourceFiles: Array.isArray(s.sourceFiles) ? s.sourceFiles : [],
    notes: s.notes || { title: s.name || "Notes", subtitle: "", sections: [], otherResources: [] },
    audioScript: s.audioScript || "",
  };
}

function ensureUserSeed(userId: string) {
  const all = loadAll();
  const hasAny = all.classes.some((c) => c.userId === userId);
  if (!hasAny) {
    const seed = seedForUser(userId);
    all.classes = [...all.classes, ...seed.classes];
    all.studySets = [...all.studySets, ...seed.studySets];
    saveAll(all);
  }
}

export function getCurrentUser(): User | null {
  return getSessionUser();
}

/** @deprecated use signIn from auth */
export function login(_email: string, _password: string): User {
  const u = getSessionUser();
  if (u) return u;
  return { id: "anon", name: "Guest", email: "guest@local", role: "student" };
}

export function logout() {
  // Prefer auth.signOut — this is a thin wrapper for older imports
  if (typeof window !== "undefined") {
    localStorage.removeItem("studious-ai-session-v1");
  }
}

export function getClasses(): Class[] {
  const user = getSessionUser();
  if (!user) return [];
  ensureUserSeed(user.id);
  const all = loadAll();
  return all.classes
    .filter((c) => c.userId === user.id && !c.archived)
    .sort((a, b) => b.lastAccessed.localeCompare(a.lastAccessed));
}

export function getAllClassesIncludingArchived(): Class[] {
  const user = getSessionUser();
  if (!user) return [];
  ensureUserSeed(user.id);
  return loadAll().classes.filter((c) => c.userId === user.id);
}

export function getClass(id: string): Class | undefined {
  const user = getSessionUser();
  if (!user) return undefined;
  return loadAll().classes.find((c) => c.id === id && c.userId === user.id);
}

export function addClass(input: {
  name: string;
  code: string;
  subject: string;
  schoolName?: string;
  semester?: string;
  professorName?: string;
  professorInsight?: string;
  textbook?: string;
  textbookAuthor?: string;
  scheduleDays?: string;
  scheduleTime?: string;
  syllabusFile?: string;
  syllabusText?: string;
  miscNotes?: string;
  alerts?: Class["alerts"];
  upcoming?: Class["upcoming"];
}): Class {
  const user = getSessionUser();
  if (!user) throw new Error("Not signed in");
  const all = loadAll();
  const now = new Date().toISOString();
  const cls: Class = {
    id: uid("c"),
    userId: user.id,
    name: input.name,
    code: input.code,
    subject: input.subject,
    createdAt: now,
    lastAccessed: now,
    schoolName: input.schoolName,
    semester: input.semester,
    professorName: input.professorName,
    professorInsight: input.professorInsight,
    textbook: input.textbook,
    textbookAuthor: input.textbookAuthor,
    scheduleDays: input.scheduleDays,
    scheduleTime: input.scheduleTime,
    syllabusFile: input.syllabusFile,
    syllabusText: input.syllabusText,
    miscNotes: input.miscNotes,
    alerts: input.alerts,
    upcoming: input.upcoming,
  };
  all.classes.unshift(cls);
  saveAll(all);
  if (user.id) upsertClassCloud(user.id, cls).catch(() => {});
  return cls;
}

export function updateClass(
  id: string,
  patch: Partial<
    Pick<
      Class,
      | "name"
      | "code"
      | "subject"
      | "archived"
      | "schoolName"
      | "semester"
      | "professorName"
      | "professorInsight"
      | "textbook"
      | "textbookAuthor"
      | "scheduleDays"
      | "scheduleTime"
      | "syllabusFile"
      | "syllabusText"
      | "miscNotes"
      | "alerts"
      | "upcoming"
    >
  >
): Class | null {
  const user = getSessionUser();
  if (!user) return null;
  const all = loadAll();
  const idx = all.classes.findIndex((c) => c.id === id && c.userId === user.id);
  if (idx < 0) return null;
  all.classes[idx] = { ...all.classes[idx], ...patch };
  saveAll(all);
  return all.classes[idx];
}

export function touchClass(id: string) {
  const user = getSessionUser();
  if (!user) return;
  const all = loadAll();
  const idx = all.classes.findIndex((c) => c.id === id && c.userId === user.id);
  if (idx >= 0) {
    all.classes[idx].lastAccessed = new Date().toISOString();
    saveAll(all);
  }
}

export function getStudySetsForClass(classId: string): StudySet[] {
  const user = getSessionUser();
  if (!user) return [];
  return loadAll()
    .studySets.filter((s) => s.classId === classId && s.userId === user.id)
    .map(normalizeStudySet)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function getStudySet(id: string): StudySet | undefined {
  const user = getSessionUser();
  if (!user) return undefined;
  const s = loadAll().studySets.find((x) => x.id === id && x.userId === user.id);
  return s ? normalizeStudySet(s) : undefined;
}

export function addStudySet(
  input: Omit<StudySet, "id" | "createdAt"> & { id?: string }
): StudySet {
  const user = getSessionUser();
  if (!user) throw new Error("Not signed in");
  const all = loadAll();
  const set: StudySet = normalizeStudySet({
    ...input,
    id: input.id || uid("s"),
    userId: user.id,
    createdAt: new Date().toISOString(),
    flashcards: input.flashcards || [],
  });
  all.studySets.unshift(set);
  saveAll(all);
  upsertSetCloud(user.id, set).catch(() => {});
  return set;
}

export function saveGeneratedSet(
  classId: string,
  name: string,
  files: string[],
  generated: {
    notes: StudySet["notes"];
    audioScript: string;
    quiz: StudySet["quiz"];
    flashcards?: StudySet["flashcards"];
  },
  focusPrompt?: string
): StudySet {
  return addStudySet({
    classId,
    name,
    notes: generated.notes,
    audioScript: generated.audioScript,
    quiz: generated.quiz,
    flashcards: generated.flashcards || [],
    sourceFiles: files,
    focusPrompt,
  });
}

/** @deprecated */
export function generateMockStudySet(
  classId: string,
  name: string,
  files: string[]
): StudySet {
  return saveGeneratedSet(classId, name, files, {
    notes: {
      title: name,
      subtitle: "Generated by Studious AI",
      sections: [
        {
          heading: "Key Concepts",
          bullets: ["Core idea from your materials"],
        },
      ],
      otherResources: [],
    },
    audioScript: `Welcome to this Studious AI review of ${name}.`,
    quiz: [],
    flashcards: [],
  });
}


export function updateStudySet(
  id: string,
  patch: Partial<Pick<StudySet, "name" | "sourceFiles">>
): StudySet | null {
  const user = getSessionUser();
  if (!user) return null;
  const all = loadAll();
  const idx = all.studySets.findIndex((s) => s.id === id && s.userId === user.id);
  if (idx < 0) return null;
  all.studySets[idx] = { ...all.studySets[idx], ...patch };
  saveAll(all);
  return all.studySets[idx];
}

export function deleteStudySet(id: string): boolean {
  const user = getSessionUser();
  if (!user) return false;
  const all = loadAll();
  const next = all.studySets.filter((s) => !(s.id === id && s.userId === user.id));
  if (next.length === all.studySets.length) return false;
  all.studySets = next;
  saveAll(all);
  return true;
}
