"use client";

export type AccountRole = "student" | "teacher" | "both";
export type EditionView = "student" | "teacher";

export interface UserProfile {
  role: AccountRole;
  phone: string;
  smsAlerts: boolean;
  schoolSelect: string;
  paletteId?: string;
  setupComplete: boolean;
  edition: EditionView;
  avatarDataUrl?: string;
}

const KEY = "studious-user-profile-v1";

export const DEFAULT_PROFILE: UserProfile = {
  role: "student",
  phone: "",
  smsAlerts: false,
  schoolSelect: "studious",
  paletteId: "studious",
  setupComplete: false,
  edition: "student",
  avatarDataUrl: "",
};

export function initialsFromName(name?: string) {
  const parts = (name || "").trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "S";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function fileToDataUrl(file: File, max = 256): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(img.width * scale));
      canvas.height = Math.max(1, Math.round(img.height * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject(new Error("canvas"));
        return;
      }
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = () => reject(new Error("image"));
    img.src = url;
  });
}

export function getUserProfile(): UserProfile {
  if (typeof window === "undefined") return DEFAULT_PROFILE;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_PROFILE;
    return { ...DEFAULT_PROFILE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function saveUserProfile(patch: Partial<UserProfile>): UserProfile {
  const next = { ...getUserProfile(), ...patch };
  localStorage.setItem(KEY, JSON.stringify(next));
  window.dispatchEvent(new Event("studious-profile-change"));
  return next;
}

export function clearUserProfile() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(KEY);
  window.dispatchEvent(new Event("studious-profile-change"));
}
