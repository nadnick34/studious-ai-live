"use client";

/**
 * Safe sync: never wipes cloud data.
 * - Pulls the signed-in user's cloud rows
 * - Uploads any local-only rows (upsert by id)
 * - Merges both into localStorage so the UI keeps working offline
 */

import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";
import type { Class, StudySet } from "@/types";

const STORAGE_KEY = "studious-ai-v3";

type Blob = {
  classes: Class[];
  studySets: StudySet[];
};

function loadLocal(): Blob {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { classes: [], studySets: [] };
    const parsed = JSON.parse(raw);
    return {
      classes: parsed.classes || [],
      studySets: parsed.studySets || [],
    };
  } catch {
    return { classes: [], studySets: [] };
  }
}

function saveLocal(blob: Blob) {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const prev = raw ? JSON.parse(raw) : {};
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        ...prev,
        classes: blob.classes,
        studySets: blob.studySets,
      })
    );
  } catch {
    /* ignore quota */
  }
}

function byId<T extends { id: string }>(rows: T[]) {
  const map = new Map<string, T>();
  rows.forEach((r) => map.set(r.id, r));
  return map;
}

export async function syncUserData(userId: string): Promise<void> {
  if (!isSupabaseConfigured()) return;
  const supabase = createClient();
  if (!supabase) return;
  // Local demo ids are not auth UUIDs — skip cloud write to avoid errors
  if (!userId.includes("-") || userId.startsWith("admin-") || userId.startsWith("student-")) {
    return;
  }

  const local = loadLocal();
  const mineClasses = local.classes.filter((c) => !c.userId || c.userId === userId);
  const mineSets = local.studySets.filter((s) => !s.userId || s.userId === userId);

  const { data: cloudClasses } = await supabase
    .from("classes")
    .select("*")
    .eq("user_id", userId);

  const { data: cloudSets } = await supabase
    .from("study_sets")
    .select("*")
    .eq("user_id", userId);

  const remoteClasses: Class[] = (cloudClasses || []).map(fromCloudClass);
  const remoteSets: StudySet[] = (cloudSets || []).map(fromCloudSet);

  // Merge: prefer newest lastAccessed / createdAt; never drop a side
  const classMap = byId([...remoteClasses, ...mineClasses.map((c) => ({ ...c, userId }))]);
  const setMap = byId([...remoteSets, ...mineSets.map((s) => ({ ...s, userId }))]);

  const merged: Blob = {
    classes: Array.from(classMap.values()),
    studySets: Array.from(setMap.values()),
  };
  saveLocal(merged);

  // Upsert local-origin rows to cloud (does not delete anything)
  if (mineClasses.length) {
    await supabase.from("classes").upsert(mineClasses.map(toCloudClass(userId)), {
      onConflict: "id",
    });
  }
  if (mineSets.length) {
    await supabase.from("study_sets").upsert(mineSets.map(toCloudSet(userId)), {
      onConflict: "id",
    });
  }
}

function toCloudClass(userId: string) {
  return (c: Class) => ({
    id: c.id,
    user_id: userId,
    name: c.name,
    code: c.code,
    subject: c.subject,
    created_at: c.createdAt,
    last_accessed: c.lastAccessed,
    archived: !!c.archived,
    school_name: c.schoolName || null,
    semester: c.semester || null,
    professor_name: c.professorName || null,
    professor_insight: c.professorInsight || null,
    textbook: c.textbook || null,
    textbook_author: c.textbookAuthor || null,
    schedule_days: c.scheduleDays || null,
    schedule_time: c.scheduleTime || null,
    syllabus_file: c.syllabusFile || null,
    misc_notes: c.miscNotes || null,
  });
}

function fromCloudClass(row: Record<string, unknown>): Class {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    name: String(row.name || ""),
    code: String(row.code || ""),
    subject: String(row.subject || ""),
    createdAt: String(row.created_at || new Date().toISOString()),
    lastAccessed: String(row.last_accessed || row.created_at || new Date().toISOString()),
    archived: Boolean(row.archived),
    schoolName: (row.school_name as string) || undefined,
    semester: (row.semester as string) || undefined,
    professorName: (row.professor_name as string) || undefined,
    professorInsight: (row.professor_insight as string) || undefined,
    textbook: (row.textbook as string) || undefined,
    textbookAuthor: (row.textbook_author as string) || undefined,
    scheduleDays: (row.schedule_days as string) || undefined,
    scheduleTime: (row.schedule_time as string) || undefined,
    syllabusFile: (row.syllabus_file as string) || undefined,
    miscNotes: (row.misc_notes as string) || undefined,
  };
}

function toCloudSet(userId: string) {
  return (s: StudySet) => ({
    id: s.id,
    user_id: userId,
    class_id: s.classId,
    name: s.name,
    created_at: s.createdAt,
    source_files: s.sourceFiles || [],
    notes: s.notes || {},
    audio_script: s.audioScript || "",
    quiz: s.quiz || [],
    flashcards: s.flashcards || [],
    focus_prompt: s.focusPrompt || null,
  });
}

function fromCloudSet(row: Record<string, unknown>): StudySet {
  return {
    id: String(row.id),
    classId: String(row.class_id),
    userId: String(row.user_id),
    name: String(row.name || ""),
    createdAt: String(row.created_at || new Date().toISOString()),
    sourceFiles: (row.source_files as string[]) || [],
    notes: (row.notes as StudySet["notes"]) || { title: "", subtitle: "", sections: [], otherResources: [] },
    audioScript: String(row.audio_script || ""),
    quiz: (row.quiz as StudySet["quiz"]) || [],
    flashcards: (row.flashcards as StudySet["flashcards"]) || [],
    focusPrompt: (row.focus_prompt as string) || undefined,
  };
}

export async function upsertClassCloud(userId: string, cls: Class) {
  if (!isSupabaseConfigured()) return;
  const supabase = createClient();
  if (!supabase || userId.startsWith("admin-") || userId.startsWith("student-")) return;
  const { error } = await supabase.from("classes").upsert(toCloudClass(userId)(cls), { onConflict: "id" });
  if (error) console.warn("[studious] class sync:", error.message);
}

export async function upsertSetCloud(userId: string, set: StudySet) {
  if (!isSupabaseConfigured()) return;
  const supabase = createClient();
  if (!supabase || userId.startsWith("admin-") || userId.startsWith("student-")) return;
  const { error } = await supabase.from("study_sets").upsert(toCloudSet(userId)(set), { onConflict: "id" });
  if (error) console.warn("[studious] set sync:", error.message);
}
