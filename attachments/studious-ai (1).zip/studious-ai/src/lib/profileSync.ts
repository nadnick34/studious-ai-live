"use client";

import { brandFromStock, getSavedBrand, saveBrand, type SavedBrand } from "@/lib/branding";
import { DEFAULT_BRAND, FALLBACK_PALETTES } from "@/lib/schools";
import { getUserProfile, saveUserProfile, type AccountRole, type EditionView } from "@/lib/profile";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

function brandFromPrefs(schoolSelect: string, logoUrl?: string): SavedBrand {
  if (schoolSelect && schoolSelect !== "custom" && schoolSelect !== "studious") {
    const stock = brandFromStock(schoolSelect);
    if (stock) return { ...stock, logoUrl };
  }
  if (schoolSelect === "custom") {
    const pal = FALLBACK_PALETTES[0];
    return {
      id: "custom",
      name: "Custom school",
      location: "",
      kind: "custom",
      primary: pal.primary,
      accent: pal.accent,
      initials: "CS",
      logoUrl,
    };
  }
  return { ...DEFAULT_BRAND, logoUrl };
}

export async function pullProfilePrefs(userId: string) {
  if (!userId || !isSupabaseConfigured()) return;
  if (!userId.includes("-") || userId.startsWith("admin-") || userId.startsWith("student-")) return;
  const supabase = createClient();
  if (!supabase) return;

  const { data, error } = await supabase
    .from("profiles")
    .select("phone, sms_alerts, school_select, account_role, edition, avatar_data_url, brand_json")
    .eq("id", userId)
    .maybeSingle();

  if (error) {
    console.warn("[studious] profile pull:", error.message);
    return;
  }
  if (!data) return;

  const schoolSelect = data.school_select || "studious";
  const cloudBrand = (data.brand_json || {}) as SavedBrand;

  saveUserProfile({
    phone: data.phone || "",
    smsAlerts: !!data.sms_alerts,
    schoolSelect,
    role: (data.account_role as AccountRole) || "student",
    edition: (data.edition as EditionView) || "student",
    avatarDataUrl: data.avatar_data_url || "",
    setupComplete: Boolean(data.school_select || data.brand_json || data.account_role),
  });

  if (cloudBrand && cloudBrand.primary) {
    saveBrand(cloudBrand);
  } else {
    saveBrand(brandFromPrefs(schoolSelect, cloudBrand.logoUrl));
  }
}

export async function pushProfilePrefs(
  userId: string,
  session?: { email?: string; name?: string }
): Promise<{ ok: boolean; error?: string }> {
  if (!userId || !isSupabaseConfigured()) {
    return { ok: false, error: "Supabase is not configured." };
  }
  if (!userId.includes("-") || userId.startsWith("admin-") || userId.startsWith("student-")) {
    return { ok: false, error: "This account is local-only." };
  }
  const supabase = createClient();
  if (!supabase) return { ok: false, error: "Supabase is not configured." };

  const p = getUserProfile();
  const brand = getSavedBrand();
  const slimBrand = {
    id: brand.id,
    name: brand.name,
    location: brand.location,
    kind: brand.kind,
    primary: brand.primary,
    accent: brand.accent,
    initials: brand.initials,
    mascot: brand.mascot,
  };

  const prefs = {
    phone: p.phone || null,
    sms_alerts: p.smsAlerts,
    school_select: p.schoolSelect,
    account_role: p.role,
    edition: p.edition,
    avatar_data_url: p.avatarDataUrl || null,
    brand_json: { ...slimBrand, logoUrl: brand.logoUrl },
  };

  const { data, error } = await supabase.from("profiles").update(prefs).eq("id", userId).select("id");
  if (!error && data && data.length) return { ok: true };

  const { data: upserted, error: upsertError } = await supabase
    .from("profiles")
    .upsert(
      {
        id: userId,
        email: session?.email || "",
        name: session?.name || "Student",
        ...prefs,
      },
      { onConflict: "id" }
    )
    .select("id");

  if (!upsertError && upserted && upserted.length) return { ok: true };

  const { error: slimError } = await supabase
    .from("profiles")
    .update({
      school_select: p.schoolSelect,
      account_role: p.role,
      brand_json: slimBrand,
    })
    .eq("id", userId);

  if (!slimError) return { ok: true };
  return { ok: false, error: upsertError?.message || error?.message || slimError.message };
}
