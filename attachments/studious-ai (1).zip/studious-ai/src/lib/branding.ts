"use client";

import { applyBrand, clearBrandVars, DEFAULT_BRAND, getStockById, type SchoolBrand } from "@/lib/schools";

const KEY = "studious-brand-v1";

export interface SavedBrand extends SchoolBrand {
  logoUrl?: string;
}

export function getSavedBrand(): SavedBrand {
  if (typeof window === "undefined") return DEFAULT_BRAND;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_BRAND;
    return JSON.parse(raw) as SavedBrand;
  } catch {
    return DEFAULT_BRAND;
  }
}

export function saveBrand(brand: SavedBrand) {
  localStorage.setItem(KEY, JSON.stringify(brand));
  applyBrand(brand);
  window.dispatchEvent(new Event("studious-brand-change"));
}

export function resetBrand() {
  localStorage.removeItem(KEY);
  clearBrandVars();
  window.dispatchEvent(new Event("studious-brand-change"));
}

export function hydrateBrand() {
  const brand = getSavedBrand();
  if (brand.id === "studious") clearBrandVars();
  else applyBrand(brand);
  return brand;
}

export function brandFromStock(id: string): SavedBrand | null {
  const s = getStockById(id);
  return s ? { ...s } : null;
}
