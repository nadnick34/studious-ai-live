"use client";

import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";
import { syncUserData } from "@/lib/sync";
import { pullProfilePrefs } from "@/lib/profileSync";
import { clearUserProfile } from "@/lib/profile";
import { resetBrand } from "@/lib/branding";
import type { User, UserRole } from "@/types";

const LOCAL_USERS_KEY = "studious-ai-users-v1";
const LOCAL_SESSION_KEY = "studious-ai-session-v1";

type LocalUserRecord = {
  id: string;
  name: string;
  email: string;
  password: string; // demo only — use Supabase in production
  role: UserRole;
  createdAt: string;
};

function loadLocalUsers(): LocalUserRecord[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(LOCAL_USERS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* ignore */
  }
  // Seed admin + sample student for local demo
  const seed: LocalUserRecord[] = [
    {
      id: "admin-1",
      name: "Admin",
      email: "admin@getstudious.ai",
      password: "admin123",
      role: "admin",
      createdAt: new Date().toISOString(),
    },
    {
      id: "student-1",
      name: "Parker",
      email: "parker@uark.edu",
      password: "password",
      role: "student",
      createdAt: new Date().toISOString(),
    },
  ];
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(seed));
  return seed;
}

function saveLocalUsers(users: LocalUserRecord[]) {
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
}

export function getSessionUser(): User | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(LOCAL_SESSION_KEY);
    if (raw) return JSON.parse(raw) as User;
  } catch {
    /* ignore */
  }
  return null;
}

export function setSessionUser(user: User | null) {
  if (typeof window === "undefined") return;
  if (user) localStorage.setItem(LOCAL_SESSION_KEY, JSON.stringify(user));
  else localStorage.removeItem(LOCAL_SESSION_KEY);
}

/** Sign up — Supabase if configured, otherwise local multi-user */
export async function signUp(input: {
  name: string;
  email: string;
  password: string;
}): Promise<{ user?: User; error?: string }> {
  const email = input.email.trim().toLowerCase();
  const name = input.name.trim();
  const password = input.password;

  if (!name || !email || password.length < 6) {
    return { error: "Name, email, and a password of at least 6 characters are required." };
  }

  if (isSupabaseConfigured()) {
    const supabase = createClient();
    if (!supabase) return { error: "Auth is not configured." };

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { name, role: "student" } },
    });

    if (error) return { error: error.message };
    if (!data.user) return { error: "Sign up failed." };

    // Profile row (trigger may also create this)
    await supabase.from("profiles").upsert({
      id: data.user.id,
      email,
      name,
      role: "student",
    });

    const user: User = {
      id: data.user.id,
      email,
      name,
      role: "student",
    };
    clearUserProfile();
    resetBrand();
    setSessionUser(user);
    try { await syncUserData(user.id); } catch { /* keep local data */ }
    return { user };
  }

  // Local fallback
  const users = loadLocalUsers();
  if (users.some((u) => u.email === email)) {
    return { error: "An account with this email already exists." };
  }

  const record: LocalUserRecord = {
    id: "u_" + Date.now().toString(36),
    name,
    email,
    password,
    role: "student",
    createdAt: new Date().toISOString(),
  };
  users.push(record);
  saveLocalUsers(users);

  const user: User = {
    id: record.id,
    name: record.name,
    email: record.email,
    role: record.role,
    createdAt: record.createdAt,
  };
  clearUserProfile();
  resetBrand();
  setSessionUser(user);
  return { user };
}

/** Sign in */
export async function signIn(input: {
  email: string;
  password: string;
}): Promise<{ user?: User; error?: string }> {
  const email = input.email.trim().toLowerCase();
  const password = input.password;

  if (isSupabaseConfigured()) {
    const supabase = createClient();
    if (!supabase) return { error: "Auth is not configured." };

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) return { error: error.message };
    if (!data.user) return { error: "Sign in failed." };

    const { data: profile } = await supabase
      .from("profiles")
      .select("name, role, email")
      .eq("id", data.user.id)
      .single();

    const user: User = {
      id: data.user.id,
      email: profile?.email || data.user.email || email,
      name: profile?.name || data.user.user_metadata?.name || "Student",
      role: (profile?.role as UserRole) || "student",
    };
    setSessionUser(user);
    try { await syncUserData(user.id); } catch { /* keep local data */ }
    try { await pullProfilePrefs(user.id); } catch { /* keep local prefs */ }
    return { user };
  }

  const users = loadLocalUsers();
  const match = users.find((u) => u.email === email && u.password === password);
  if (!match) return { error: "Invalid email or password." };

  const user: User = {
    id: match.id,
    name: match.name,
    email: match.email,
    role: match.role,
    createdAt: match.createdAt,
  };
  setSessionUser(user);
  return { user };
}

export async function signOut() {
  if (isSupabaseConfigured()) {
    const supabase = createClient();
    if (supabase) await supabase.auth.signOut();
  }
  setSessionUser(null);
  clearUserProfile();
  resetBrand();
}

/** Admin: list all users (local or Supabase) */
export async function listUsers(): Promise<User[]> {
  if (isSupabaseConfigured()) {
    const supabase = createClient();
    if (!supabase) return [];
    const { data } = await supabase
      .from("profiles")
      .select("id, name, email, role, created_at")
      .order("created_at", { ascending: false });
    return (data || []).map((p) => ({
      id: p.id,
      name: p.name,
      email: p.email,
      role: p.role as UserRole,
      createdAt: p.created_at,
    }));
  }

  return loadLocalUsers().map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    createdAt: u.createdAt,
  }));
}

export async function setUserRole(userId: string, role: UserRole): Promise<{ error?: string }> {
  if (isSupabaseConfigured()) {
    const supabase = createClient();
    if (!supabase) return { error: "Not configured" };
    const { error } = await supabase.from("profiles").update({ role }).eq("id", userId);
    return error ? { error: error.message } : {};
  }

  const users = loadLocalUsers();
  const idx = users.findIndex((u) => u.id === userId);
  if (idx < 0) return { error: "User not found" };
  users[idx].role = role;
  saveLocalUsers(users);
  return {};
}
