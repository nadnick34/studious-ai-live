export type UserRole = "student" | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  createdAt?: string;
}

export interface StudySet {
  id: string;
  classId: string;
  userId?: string;
  name: string;
  createdAt: string;
  notes: StudyNotes;
  audioScript: string;
  quiz: QuizQuestion[];
  flashcards: FlashCard[];
  sourceFiles: string[];
  focusPrompt?: string;
}

export interface NotesSection {
  heading: string;
  /** Default bullet list */
  bullets?: string[];
  /** Optional short intro paragraph under the heading */
  body?: string;
  reference?: string;
  /** Visual layout hint for the notes viewer / print */
  layout?: "stack" | "two-column" | "table";
  /** Used when layout is two-column */
  columns?: { title: string; bullets: string[] }[];
  /** Used when layout is table */
  table?: { headers: string[]; rows: string[][] };
}

export interface StudyNotes {
  title: string;
  subtitle: string;
  sections: NotesSection[];
  otherResources: { title: string; url?: string }[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
}

export interface FlashCard {
  id: string;
  term: string;
  definition: string;
}

export interface Class {
  id: string;
  userId?: string;
  name: string;
  code: string;
  subject: string;
  createdAt: string;
  lastAccessed: string;
  archived?: boolean;
  schoolName?: string;
  semester?: string;
  professorName?: string;
  professorInsight?: string;
  textbook?: string;
  textbookAuthor?: string;
  scheduleDays?: string;
  scheduleTime?: string;
  syllabusFile?: string;
  syllabusText?: string;
  miscNotes?: string;
  alerts?: ClassAlert[];
  upcoming?: ClassUpcoming[];
}

export interface ClassAlert {
  id: string;
  message: string;
  kind?: "due-soon" | "exam" | "reading" | "policy";
}

export interface ClassUpcoming {
  id: string;
  type: "assignment" | "exam" | "quiz" | "reading" | "other";
  title: string;
  date?: string;
  note?: string;
}

export interface AppState {
  user: User | null;
  classes: Class[];
  studySets: StudySet[];
}
