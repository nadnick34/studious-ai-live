"use client";

import { useState } from "react";
import Link from "next/link";
import Button from "@/components/Button";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/client";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    if (isSupabaseConfigured()) {
      const supabase = createClient();
      if (!supabase) {
        setError("Auth is not configured.");
        setLoading(false);
        return;
      }
      const { error: err } = await supabase.auth.resetPasswordForEmail(email.trim(), {
        redirectTo: typeof window !== "undefined" ? `${window.location.origin}/login` : undefined,
      });
      setLoading(false);
      if (err) {
        setError(err.message);
        return;
      }
      setSent(true);
      return;
    }

    // Local mode — no email server
    setLoading(false);
    setSent(true);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--slate-dark)] px-4">
      <div className="w-full max-w-[380px] bg-[var(--card)] rounded-2xl shadow-lg border border-[var(--border)] p-8">
        <h1 className="text-lg font-bold text-center mb-1">Reset password</h1>
        <p className="text-xs text-[var(--muted)] text-center mb-6">
          Enter your account email and we’ll help you get back in.
        </p>

        {sent ? (
          <div className="text-sm text-[var(--text)] space-y-3">
            <p>
              {isSupabaseConfigured()
                ? `If an account exists for ${email}, a reset link has been sent.`
                : "Local demo mode: password reset email is not available yet. Use a demo account or create a new one. When Supabase is connected, real reset emails will work."}
            </p>
            <Link href="/login" className="block text-center text-[var(--teal)] font-medium hover:underline">
              Back to sign in
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-medium text-[var(--muted)] mb-1">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5 text-sm outline-none focus:border-[var(--teal)]"
              />
            </div>
            {error && (
              <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{error}</div>
            )}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Sending…" : "Send reset link"}
            </Button>
            <p className="text-center text-xs text-[var(--muted)]">
              <Link href="/login" className="text-[var(--teal)] hover:underline">
                Back to sign in
              </Link>
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
