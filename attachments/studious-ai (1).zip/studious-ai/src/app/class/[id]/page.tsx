"use client";

import { useEffect, useRef, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import { getClass, getStudySetsForClass, touchClass, saveGeneratedSet, updateStudySet, deleteStudySet } from "@/lib/store";
import type { Class, StudySet } from "@/types";

function formatDate(iso: string) {
  const d = new Date(iso);
  return (
    d.toLocaleDateString("en-US", { month: "short", day: "numeric" }) +
    ", " +
    d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
  );
}

export default function ClassPage() {
  const params = useParams();
  const router = useRouter();
  const classId = params.id as string;

  const [cls, setCls] = useState<Class | null>(null);
  const [sets, setSets] = useState<StudySet[]>([]);
  const [showCombine, setShowCombine] = useState(false);
  const [showFocus, setShowFocus] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [focusText, setFocusText] = useState("");
  const [focusName, setFocusName] = useState("");
  const [combineBusy, setCombineBusy] = useState(false);
  const [combineStatus, setCombineStatus] = useState("");
  const [combineError, setCombineError] = useState<string | null>(null);
  const [focusBusy, setFocusBusy] = useState(false);
  const [focusError, setFocusError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const combineCancelled = useRef(false);

  function refresh() {
    setSets(getStudySetsForClass(classId));
  }

  useEffect(() => {
    const c = getClass(classId);
    if (!c) {
      router.replace("/dashboard");
      return;
    }
    touchClass(classId);
    setCls(c);
    setSets(getStudySetsForClass(classId));
  }, [classId, router]);

  async function handleCustomFocus() {
    if (!cls || !focusText.trim()) {
      setFocusError("Describe what you want to focus on.");
      return;
    }
    setFocusError(null);
    setFocusBusy(true);

    const setName =
      focusName.trim() ||
      `Focus: ${focusText.trim().slice(0, 40)}${focusText.trim().length > 40 ? "…" : ""}`;

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          classId,
          className: cls.name,
          classCode: cls.code,
          subject: cls.subject,
          setName,
          sourceFiles: ["Custom Focus request"],
          focusPrompt: focusText.trim(),
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || `Generation failed (${res.status})`);
      }

      const generated = await res.json();
      const set = saveGeneratedSet(
        classId,
        setName,
        ["Custom Focus"],
        {
          notes: generated.notes,
          audioScript: generated.audioScript,
          quiz: generated.quiz,
          flashcards: generated.flashcards || [],
        },
        focusText.trim()
      );

      setShowFocus(false);
      setFocusText("");
      setFocusName("");
      setFocusBusy(false);
      refresh();
      router.push(`/class/${classId}/set/${set.id}`);
    } catch (err) {
      setFocusError(err instanceof Error ? err.message : "Something went wrong");
      setFocusBusy(false);
    }
  }


  async function handleCombine() {
    if (!cls || selected.length < 2 || combineBusy) return;
    combineCancelled.current = false;
    const chosen = sets.filter((s) => selected.includes(s.id));
    const extractedText = chosen
      .map((s) => {
        const secs = (s.notes?.sections || [])
          .map((sec) => {
            const bits = [
              sec.heading,
              sec.body || "",
              (sec.bullets || []).join("\n"),
            ].filter(Boolean);
            return bits.join("\n");
          })
          .join("\n\n");
        return `===== ${s.name} =====\n${s.notes?.title || ""}\n${secs}`;
      })
      .join("\n\n");

    setCombineBusy(true);
    setCombineError(null);
    setCombineStatus("Combining selected chapters…");
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          classId,
          className: cls.name,
          classCode: cls.code,
          subject: cls.subject,
          setName: "Midterm / Final review",
          sourceFiles: chosen.map((s) => s.name),
          extractedText,
          focusPrompt: "Combine these chapter notes into one comprehensive midterm/final review. Preserve all key definitions, tables, and distinctions.",
        }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Combine failed");
      }
      const generated = await res.json();
      if (combineCancelled.current) {
        setCombineBusy(false);
        setCombineStatus("");
        return;
      }
      const set = saveGeneratedSet(
        classId,
        "Midterm / Final review",
        chosen.map((s) => s.name),
        {
          notes: generated.notes,
          audioScript: generated.audioScript,
          quiz: generated.quiz,
          flashcards: generated.flashcards || [],
        }
      );
      setShowCombine(false);
      setSelected([]);
      setCombineBusy(false);
      setCombineStatus("");
      refresh();
      router.push(`/class/${classId}/set/${set.id}`);
    } catch (err) {
      setCombineBusy(false);
      setCombineStatus("");
      setCombineError(err instanceof Error ? err.message : "Combine failed");
    }
  }

  if (!cls) return null;

  return (
    <AppShell
      title="My Classes"
      right={
        <div className="flex gap-2 flex-wrap justify-end">
          <Button variant="secondary" onClick={() => setShowFocus(true)}>
            Custom Focus
          </Button>
          <Button variant="secondary" onClick={() => setShowCombine(true)}>
            Combine for Midterm / Final
          </Button>
          <Link href={`/class/${classId}/upload`}>
            <Button>+ Upload Materials</Button>
          </Link>
        </div>
      }
    >
      <div className="mb-1 text-xs text-[var(--muted)]">Class Detail</div>
      <h2 className="text-lg font-bold text-[var(--text)] mb-5">
        {cls.code} – {cls.name}
      </h2>

      <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/40 border-b border-[var(--border)] text-left text-xs font-semibold uppercase tracking-wide text-[var(--muted)]">
                <th className="px-4 py-3">Date / Time</th>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Material (PDF)</th>
                <th className="px-4 py-3">Audio</th>
                <th className="px-4 py-3">Flash Cards</th>
                <th className="px-4 py-3">Quiz</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sets.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-[var(--muted)]">
                    No study sets yet. Upload materials or use Custom Focus to get started.
                  </td>
                </tr>
              )}
              {sets.map((s) => (
                <tr
                  key={s.id}
                  className="border-b border-[var(--border)] last:border-0 hover:bg-slate-50 dark:bg-slate-800/40 dark:hover:bg-slate-800/60/80"
                >
                  <td className="px-4 py-3.5 text-[var(--muted)] whitespace-nowrap">
                    {formatDate(s.createdAt)}
                  </td>
                  <td className="px-4 py-3.5 font-medium text-[var(--text)]">
                    {s.name}
                    {s.focusPrompt && (
                      <span className="ml-2 text-[10px] uppercase tracking-wide text-amber-800 bg-amber-50 dark:text-amber-200 dark:bg-amber-900/40 px-1.5 py-0.5 rounded">
                        Focus
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3.5">
                    <Link
                      href={`/class/${classId}/set/${s.id}`}
                      className="inline-flex items-center gap-1 text-[var(--teal)] hover:underline font-medium"
                    >
                      <span className="text-xs">↓</span> Open PDF
                    </Link>
                  </td>
                  <td className="px-4 py-3.5">
                    <Link
                      href={`/class/${classId}/set/${s.id}/audio`}
                      className="inline-flex items-center gap-1.5 text-sky-600 dark:text-sky-400 hover:underline font-medium"
                    >
                      <span className="text-xs">▶</span> Listen
                    </Link>
                  </td>
                  <td className="px-4 py-3.5">
                    <Link
                      href={`/class/${classId}/set/${s.id}/flashcards`}
                      className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-300 hover:underline font-medium"
                    >
                      Cards
                      {s.flashcards?.length ? (
                        <span className="text-[10px] text-[var(--muted)]">
                          ({s.flashcards.length})
                        </span>
                      ) : null}
                    </Link>
                  </td>
                  <td className="px-4 py-3.5">
                    <Link
                      href={`/class/${classId}/set/${s.id}/quiz`}
                      className="inline-flex items-center gap-1 text-violet-600 dark:text-violet-300 hover:underline font-medium"
                    >
                      Start Quiz
                    </Link>
                  </td>
                  <td className="px-4 py-3.5">
                    {editingId === s.id ? (
                      <div className="flex items-center gap-1">
                        <input
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-28 sm:w-36 rounded border border-[var(--border)] bg-[var(--card)] px-2 py-1 text-xs"
                          autoFocus
                        />
                        <button
                          type="button"
                          className="text-xs text-[var(--teal)] hover:underline"
                          onClick={() => {
                            if (editName.trim()) updateStudySet(s.id, { name: editName.trim() });
                            setEditingId(null);
                            refresh();
                          }}
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          className="text-xs text-[var(--muted)] hover:underline"
                          onClick={() => setEditingId(null)}
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 whitespace-nowrap">
                        <button
                          type="button"
                          className="text-xs text-[var(--teal)] hover:underline"
                          onClick={() => {
                            setEditingId(s.id);
                            setEditName(s.name);
                          }}
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          className="text-xs text-red-600 dark:text-red-400 hover:underline"
                          onClick={() => {
                            if (confirm(`Delete “${s.name}”? This cannot be undone.`)) {
                              deleteStudySet(s.id);
                              refresh();
                            }
                          }}
                        >
                          Delete
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Combine modal */}
      {showCombine && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-[var(--card)] rounded-xl shadow-xl w-full max-w-md p-6">
            <h3 className="text-base font-semibold mb-1">Combine for Midterm / Final</h3>
            <p className="text-xs text-[var(--muted)] mb-4">
              Select chapters to merge into one study package.
            </p>
            <div className="space-y-2 max-h-60 overflow-y-auto mb-4">
              {sets.map((s) => (
                <label
                  key={s.id}
                  className="flex items-center gap-3 p-2.5 rounded-lg border border-[var(--border)] hover:bg-slate-50 dark:bg-slate-800/40 dark:hover:bg-slate-800/60 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={selected.includes(s.id)}
                    onChange={(e) => {
                      if (e.target.checked) setSelected([...selected, s.id]);
                      else setSelected(selected.filter((id) => id !== s.id));
                    }}
                    disabled={combineBusy}
                    className="rounded border-slate-300 text-[var(--teal)] focus:ring-[var(--teal)]"
                  />
                  <span className="text-sm">{s.name}</span>
                </label>
              ))}
            </div>
            {combineStatus && (
              <p className="text-sm text-[var(--teal)] mb-3">{combineStatus}</p>
            )}
            {combineError && (
              <p className="text-sm text-red-600 mb-3">{combineError}</p>
            )}
            <div className="flex justify-end gap-2">
              <Button
                variant="secondary"
                onClick={() => {
                  combineCancelled.current = true;
                  setCombineBusy(false);
                  setCombineStatus("");
                  setCombineError(null);
                  setShowCombine(false);
                }}
              >
                Cancel
              </Button>
              <Button
                disabled={selected.length < 2 || combineBusy}
                onClick={handleCombine}
              >
                {combineBusy ? "Generating…" : "Combine Selected"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Focus modal */}
      {showFocus && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-[var(--card)] rounded-xl shadow-xl w-full max-w-lg p-6">
            <h3 className="text-base font-semibold mb-1">Custom Focus</h3>
            <p className="text-xs text-[var(--muted)] mb-4">
              Tell Studious what to emphasize — a tough section, more depth on a topic, or an area
              you need extra help with. A full study package (notes, audio, flash cards, quiz) will
              be generated around that focus.
            </p>

            <div className="mb-3">
              <label className="block text-xs font-medium text-[var(--muted)] mb-1">
                Optional name for this set
              </label>
              <input
                value={focusName}
                onChange={(e) => setFocusName(e.target.value)}
                placeholder="e.g. Punnett squares deep dive"
                className="w-full rounded-lg border border-[var(--border)] px-3 py-2 text-sm outline-none focus:border-[var(--teal)]"
                disabled={focusBusy}
              />
            </div>

            <div className="mb-4">
              <label className="block text-xs font-medium text-[var(--muted)] mb-1">
                What should we focus on?
              </label>
              <textarea
                value={focusText}
                onChange={(e) => setFocusText(e.target.value)}
                placeholder="Example: Go deeper on the Columbian Exchange — especially disease and population impact. I keep mixing up primary vs secondary sources too."
                rows={4}
                className="w-full rounded-lg border border-[var(--border)] px-3 py-2 text-sm outline-none focus:border-[var(--teal)] resize-y"
                disabled={focusBusy}
                autoFocus
              />
            </div>

            {focusError && (
              <div className="mb-3 text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
                {focusError}
              </div>
            )}

            <div className="flex justify-end gap-2">
              <Button
                variant="secondary"
                onClick={() => {
                  setShowFocus(false);
                  setFocusError(null);
                }}
                disabled={focusBusy}
              >
                Cancel
              </Button>
              <Button onClick={handleCustomFocus} disabled={focusBusy}>
                {focusBusy ? "Generating…" : "Generate Focused Set"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
