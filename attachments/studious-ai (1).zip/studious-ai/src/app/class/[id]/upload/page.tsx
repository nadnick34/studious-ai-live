"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import { getClass, saveGeneratedSet } from "@/lib/store";
import type { Class } from "@/types";

export default function UploadPage() {
  const params = useParams();
  const router = useRouter();
  const classId = params.id as string;

  const [cls, setCls] = useState<Class | null>(null);
  const [name, setName] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState("");

  useEffect(() => {
    const c = getClass(classId);
    setCls(c || {
      id: classId,
      name: "Class",
      code: "",
      subject: "",
      createdAt: "",
      lastAccessed: "",
    });
  }, [classId]);

  function addFiles(list: FileList | File[] | null) {
    if (!list) return;
    const next = Array.from(list);
    if (!next.length) return;
    setFiles((prev) => [...prev, ...next]);
    setError(null);
  }

  async function handleGenerate() {
    if (!name.trim()) {
      setError("Please name this study set (for example: Chapter 2).");
      return;
    }
    if (!files.length) {
      setError("Upload at least one file before generating.");
      return;
    }
    if (!cls) return;

    setError(null);
    setGenerating(true);
    setStatus(files.length ? "Reading your files…" : "Generating…");

    try {
      let extractedText = "";
      if (files.length) {
        const form = new FormData();
        files.forEach((f) => form.append("files", f));
        const extracted = await fetch("/api/extract", { method: "POST", body: form });
        const extractedJson = await extracted.json().catch(() => ({}));
        if (!extracted.ok) {
          throw new Error(extractedJson.error || "Could not read the uploaded files");
        }
        extractedText = extractedJson.text || files.map((f) => `Uploaded file: ${f.name}`).join("\n");
      }

      setStatus("Building notes, audio, flash cards, and quiz…");
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          classId,
          className: cls.name,
          classCode: cls.code,
          subject: cls.subject,
          setName: name.trim(),
          sourceFiles: files.length ? files.map((f) => f.name) : ["No files attached"],
          extractedText,
        }),
      });

      const generated = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(generated.error || `Generation failed (${res.status})`);

      const set = saveGeneratedSet(
        classId,
        name.trim(),
        files.length ? files.map((f) => f.name) : ["No files attached"],
        {
          notes: generated.notes,
          audioScript: generated.audioScript,
          quiz: generated.quiz,
          flashcards: generated.flashcards || [],
        }
      );

      router.push(`/class/${classId}/set/${set.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
      setGenerating(false);
      setStatus("");
    }
  }

  if (!cls) return null;

  return (
    <AppShell title={`${cls.code || "Class"} – Upload`}>
      <Link href={`/class/${classId}`} className="text-sm text-[var(--teal)] hover:underline mb-4 inline-block">
        ← Back to Class
      </Link>

      <div className="max-w-lg mx-auto mt-4">
        <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-6 shadow-sm">
          <h2 className="text-base font-semibold mb-1">Upload Materials</h2>
          <p className="text-xs text-[var(--muted)] mb-5">
            Attach a PDF, notes, or images, name the set, then generate.
          </p>

          <div className="mb-4">
            <label className="block text-xs font-medium text-[var(--muted)] mb-1.5">
              Name this set
            </label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Chapter 2"
              className="w-full rounded-lg border border-[var(--border)] bg-[var(--card)] px-3 py-2.5 text-sm outline-none focus:border-[var(--teal)] text-[var(--text)]"
              disabled={generating}
            />
          </div>

          <div className="mb-4">
            <label className="block text-xs font-medium text-[var(--muted)] mb-1.5">
              Upload materials
            </label>
            <label
              onDragOver={(e) => {
                e.preventDefault();
              }}
              onDrop={(e) => {
                e.preventDefault();
                if (!generating) addFiles(e.dataTransfer.files);
              }}
              className={`flex flex-col items-center justify-center gap-2 min-h-[160px] rounded-xl border-2 border-dashed px-4 py-6 text-center cursor-pointer transition-colors ${
                generating
                  ? "opacity-60 cursor-not-allowed border-[var(--border)]"
                  : files.length
                    ? "border-[var(--teal)] bg-teal-50/40"
                    : "border-[var(--teal)] bg-[var(--bg)] hover:bg-teal-50/50"
              }`}
            >
              <input
                type="file"
                multiple
                accept=".pdf,.doc,.docx,.txt,.md,.png,.jpg,.jpeg,.webp,.gif,.mp3,.m4a,.wav,.aac"
                onChange={(e) => {
                  addFiles(e.target.files);
                  e.currentTarget.value = "";
                }}
                disabled={generating}
                className="sr-only"
              />
              <span className="inline-flex items-center justify-center rounded-lg bg-[var(--teal)] text-white text-sm font-semibold px-4 py-2">
                Choose files
              </span>
              <span className="text-sm text-[var(--text)]">
                {files.length
                  ? `${files.length} file${files.length === 1 ? "" : "s"} selected — click to add more`
                  : "Drop files here or click to browse"}
              </span>
              <span className="text-[11px] text-[var(--muted)] leading-relaxed max-w-sm">
                PDF · Word · images (PNG, JPG) · text · audio (MP3, M4A, WAV)
              </span>
            </label>
          </div>

          {files.length > 0 && (
            <ul className="mb-4 space-y-1">
              {files.map((f, i) => (
                <li
                  key={`${f.name}-${i}`}
                  className="flex items-center justify-between text-sm border border-[var(--border)] rounded-lg px-3 py-2"
                >
                  <span className="truncate pr-3">
                    {f.name}{" "}
                    <span className="text-[11px] text-[var(--muted)]">
                      ({Math.max(1, Math.round(f.size / 1024))} KB)
                    </span>
                  </span>
                  {!generating && (
                    <button
                      type="button"
                      className="text-xs text-red-600 dark:text-red-400 hover:underline shrink-0"
                      onClick={() => setFiles(files.filter((_, idx) => idx !== i))}
                    >
                      Remove
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}

          {error && (
            <div className="mb-4 text-sm text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40 border border-red-100 dark:border-red-900 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          {status && generating && (
            <div className="mb-4 text-sm text-[var(--teal)]">{status}</div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <Link href={`/class/${classId}`}>
              <Button type="button" variant="secondary" disabled={generating}>
                Cancel
              </Button>
            </Link>
            <Button
              type="button"
              onClick={handleGenerate}
              disabled={generating || !files.length || !name.trim()}
            >
              {generating ? "Generating…" : "Generate Study Materials"}
            </Button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
