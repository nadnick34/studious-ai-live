"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import { getStudySet, getClass } from "@/lib/store";
import type { StudySet, Class, QuizQuestion } from "@/types";

export default function QuizPage() {
  const params = useParams();
  const router = useRouter();
  const classId = params.id as string;
  const setId = params.setId as string;

  const [set, setSet] = useState<StudySet | null>(null);
  const [cls, setCls] = useState<Class | null>(null);
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    const s = getStudySet(setId);
    const c = getClass(classId);
    if (!s || !c) {
      router.replace("/dashboard");
      return;
    }
    setSet(s);
    setCls(c);
  }, [classId, setId, router]);

  if (!set || !cls) return null;

  const questions: QuizQuestion[] = set.quiz;
  const q = questions[index];
  const total = questions.length;

  function handleSelect(i: number) {
    if (revealed) return;
    setSelected(i);
    setRevealed(true);
    if (i === q.correctIndex) setScore((s) => s + 1);
  }

  function handleNext() {
    if (index + 1 >= total) {
      setFinished(true);
    } else {
      setIndex(index + 1);
      setSelected(null);
      setRevealed(false);
    }
  }

  function restart() {
    setIndex(0);
    setSelected(null);
    setRevealed(false);
    setScore(0);
    setFinished(false);
  }

  if (total === 0) {
    return (
      <AppShell title="Quiz">
        <Link href={`/class/${classId}`} className="text-sm text-[var(--teal)] hover:underline">
          ← Back to Class
        </Link>
        <div className="text-center mt-16 text-[var(--muted)]">No quiz questions for this set yet.</div>
      </AppShell>
    );
  }

  return (
    <AppShell title={`Quiz – ${set.name}`}>
      <div className="flex items-center justify-between mb-5">
        <Link href={`/class/${classId}`} className="text-sm text-[var(--teal)] hover:underline">
          ← Back to Class
        </Link>
        <div className="text-xs text-[var(--muted)]">{cls.code}</div>
      </div>

      <div className="max-w-lg mx-auto">
        {finished ? (
          <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-8 text-center shadow-sm">
            <div className="text-3xl font-bold text-[var(--text)] mb-1">
              {score}/{total}
            </div>
            <p className="text-sm text-[var(--muted)] mb-6">
              {score === total
                ? "Perfect — you’ve mastered this material."
                : score >= total * 0.7
                ? "Solid work. Review the missed items and try again."
                : "Keep going. Revisit the notes and audio, then retake the quiz."}
            </p>
            <div className="flex justify-center gap-2">
              <Button variant="secondary" onClick={restart}>
                Retake Quiz
              </Button>
              <Link href={`/class/${classId}/set/${setId}`}>
                <Button>Review Notes</Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-6 shadow-sm">
            <div className="h-1.5 bg-slate-100 rounded-full mb-5 overflow-hidden">
              <div
                className="h-full bg-[var(--teal)] rounded-full transition-all"
                style={{ width: `${((index + (revealed ? 1 : 0)) / total) * 100}%` }}
              />
            </div>

            <div className="text-xs text-[var(--muted)] mb-2">
              Question {index + 1} of {total}
            </div>
            <h2 className="text-base font-semibold text-[var(--text)] mb-5 leading-snug">
              {q.question}
            </h2>

            <div className="space-y-2.5">
              {q.options.map((opt, i) => {
                let style =
                  "border-[var(--border)] hover:border-[var(--teal)] hover:bg-teal-50/40 cursor-pointer";
                if (revealed) {
                  if (i === q.correctIndex) style = "border-green-400 bg-green-50 text-green-800";
                  else if (i === selected) style = "border-red-300 bg-red-50 text-red-800";
                  else style = "border-[var(--border)] opacity-60";
                } else if (selected === i) {
                  style = "border-[var(--teal)] bg-teal-50";
                }
                return (
                  <button
                    key={i}
                    onClick={() => handleSelect(i)}
                    disabled={revealed}
                    className={`w-full text-left px-4 py-3 rounded-lg border text-sm transition-colors ${style}`}
                  >
                    {opt}
                  </button>
                );
              })}
            </div>

            {revealed && q.explanation && (
              <p className="mt-4 text-xs text-[var(--muted)] bg-slate-50 dark:bg-slate-800/40 rounded-lg p-3">
                {q.explanation}
              </p>
            )}

            <div className="flex justify-between mt-6">
              <Link href={`/class/${classId}`}>
                <button className="text-sm text-[var(--muted)] hover:text-[var(--text)]">Exit</button>
              </Link>
              {revealed && (
                <Button onClick={handleNext}>
                  {index + 1 >= total ? "See Results" : "Next"}
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
