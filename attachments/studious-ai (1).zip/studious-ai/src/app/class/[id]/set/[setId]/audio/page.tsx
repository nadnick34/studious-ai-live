"use client";

import { useEffect, useState, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import { getStudySet, getClass } from "@/lib/store";
import type { StudySet, Class } from "@/types";

export default function AudioPage() {
  const params = useParams();
  const router = useRouter();
  const classId = params.id as string;
  const setId = params.setId as string;

  const [set, setSet] = useState<StudySet | null>(null);
  const [cls, setCls] = useState<Class | null>(null);
  const [loadingAudio, setLoadingAudio] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const cacheKey = `studious-audio-${setId}`;

  useEffect(() => {
    const s = getStudySet(setId);
    const c = getClass(classId);
    if (!s || !c) {
      router.replace("/dashboard");
      return;
    }
    setSet(s);
    setCls(c);
  }, [classId, setId, router]);

  async function ensureAudio(): Promise<string | null> {
    if (audioUrl) return audioUrl;
    if (!set?.audioScript) {
      setError("No lecture script available for this set.");
      return null;
    }

    setLoadingAudio(true);
    setError(null);
    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: set.audioScript, voice: "eve" }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || `Could not generate audio (${res.status})`);
      }

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
      setLoadingAudio(false);
      return url;
    } catch (err) {
      setLoadingAudio(false);
      setError(err instanceof Error ? err.message : "Audio generation failed");
      return null;
    }
  }

  async function handlePlayPause() {
    const el = audioRef.current;
    if (!el) return;

    if (playing) {
      el.pause();
      setPlaying(false);
      return;
    }

    let url = audioUrl;
    if (!url) {
      url = await ensureAudio();
      if (!url) return;
      el.src = url;
      await new Promise<void>((resolve) => {
        el.onloadeddata = () => resolve();
        el.load();
      });
    }

    try {
      await el.play();
      setPlaying(true);
    } catch {
      setError("Playback failed. Check device sound and try again.");
      setPlaying(false);
    }
  }

  function formatTime(sec: number) {
    if (!isFinite(sec) || sec < 0) return "0:00";
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s.toString().padStart(2, "0")}`;
  }

  if (!set || !cls) return null;

  return (
    <AppShell title={`Audio Lecture – ${set.name}`}>
      <div className="flex items-center justify-between mb-5">
        <Link href={`/class/${classId}`} className="text-sm text-[var(--teal)] hover:underline">
          ← Back to Class
        </Link>
        <div className="text-xs text-[var(--muted)]">{cls.code}</div>
      </div>

      <div className="max-w-md mx-auto">
        <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-8 shadow-sm text-center">
          <div className="w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6 text-slate-500" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
              <path d="M3 18v-6a9 9 0 0118 0v6" />
              <path d="M21 19a2 2 0 01-2 2h-1a2 2 0 01-2-2v-3a2 2 0 012-2h3zM3 19a2 2 0 002 2h1a2 2 0 002-2v-3a2 2 0 00-2-2H3z" />
            </svg>
          </div>

          <h2 className="font-semibold text-[var(--text)] mb-1">{set.name}</h2>
          <p className="text-xs text-[var(--muted)] mb-6">AI lecture audio</p>

          <audio
            ref={audioRef}
            preload="none"
            onTimeUpdate={(e) => {
              const a = e.currentTarget;
              setCurrentTime(a.currentTime);
              if (a.duration) setProgress((a.currentTime / a.duration) * 100);
            }}
            onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
            onEnded={() => {
              setPlaying(false);
              setProgress(100);
            }}
            onPause={() => setPlaying(false)}
            onPlay={() => setPlaying(true)}
            className="hidden"
          />

          <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full mb-2 overflow-hidden">
            <div
              className="h-full bg-[var(--teal)] rounded-full transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-[var(--muted)] mb-6">
            <span>{formatTime(currentTime)}</span>
            <span>{duration ? formatTime(duration) : "—"}</span>
          </div>

          <button
            type="button"
            onClick={handlePlayPause}
            disabled={loadingAudio}
            className="w-14 h-14 rounded-full bg-[var(--teal)] text-white flex items-center justify-center mx-auto hover:opacity-90 transition-opacity disabled:opacity-60"
            aria-label={playing ? "Pause" : "Play"}
          >
            {loadingAudio ? (
              <svg className="w-6 h-6 animate-spin" viewBox="0 0 24 24" fill="none">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
              </svg>
            ) : playing ? (
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
              </svg>
            ) : (
              <svg className="w-6 h-6 ml-0.5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            )}
          </button>

          <p className="text-xs text-[var(--muted)] mt-4">
            {loadingAudio
              ? "Generating audio file…"
              : playing
                ? "Playing"
                : audioUrl
                  ? "Ready — tap play"
                  : "Tap play to generate and play audio"}
          </p>

          {error && (
            <div className="mt-4 text-left text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <div className="mt-4">
            <Button
              variant="secondary"
              className="text-xs"
              disabled={loadingAudio}
              onClick={async () => {
                if (audioUrl) URL.revokeObjectURL(audioUrl);
                setAudioUrl(null);
                setProgress(0);
                setCurrentTime(0);
                setDuration(0);
                await ensureAudio();
              }}
            >
              Regenerate audio
            </Button>
          </div>
        </div>

        <div className="mt-6 bg-[var(--card)] border border-[var(--border)] rounded-xl p-5">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-[var(--muted)] mb-3">
            Script
          </h3>
          <p className="text-sm text-[var(--text)] leading-relaxed whitespace-pre-wrap">
            {set.audioScript}
          </p>
        </div>

        <p className="text-center text-xs text-[var(--muted)] mt-4">
          Generates a real MP3 from the lecture script using{" "}
          <strong>Grok TTS</strong> (<code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">GROK_API_KEY</code>).
        </p>
      </div>
    </AppShell>
  );
}
