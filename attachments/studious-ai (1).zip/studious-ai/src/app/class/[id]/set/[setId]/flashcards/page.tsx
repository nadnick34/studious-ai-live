"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import { getStudySet, getClass } from "@/lib/store";
import type { StudySet, Class, FlashCard } from "@/types";

export default function FlashCardsPage() {
  const params = useParams();
  const router = useRouter();
  const classId = params.id as string;
  const setId = params.setId as string;

  const [set, setSet] = useState<StudySet | null>(null);
  const [cls, setCls] = useState<Class | null>(null);
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [mode, setMode] = useState<"study" | "print">("study");
  const [reversed, setReversed] = useState(false);

  useEffect(() => {
    const s = getStudySet(setId);
    const c = getClass(classId);
    if (!s || !c) {
      router.replace("/dashboard");
      return;
    }
    setSet(s);
    setCls(c);
  }, [classId, setId, router]);

  if (!set || !cls) return null;

  const cards: FlashCard[] = set.flashcards || [];
  const card = cards[index];
  const total = cards.length;

  function next() {
    setFlipped(false);
    setIndex((i) => (i + 1) % Math.max(total, 1));
  }

  function prev() {
    setFlipped(false);
    setIndex((i) => (i - 1 + total) % Math.max(total, 1));
  }

  if (total === 0) {
    return (
      <AppShell title="Flash Cards">
        <Link href={`/class/${classId}`} className="text-sm text-[var(--teal)] hover:underline">
          ← Back to Class
        </Link>
        <div className="text-center mt-16 text-[var(--muted)]">No flash cards for this set yet.</div>
      </AppShell>
    );
  }

  const frontLabel = reversed ? "Definition" : "Term";
  const backLabel = reversed ? "Term" : "Definition";
  const frontText = reversed ? card.definition : card.term;
  const backText = reversed ? card.term : card.definition;

  return (
    <AppShell
      title={`Flash Cards – ${set.name}`}
      right={
        <div className="flex gap-2 flex-wrap justify-end">
          <Button
            variant={reversed ? "primary" : "secondary"}
            onClick={() => {
              setReversed((r) => !r);
              setFlipped(false);
            }}
            className="text-xs"
          >
            {reversed ? "Definition → Term" : "Term → Definition"}
          </Button>
          <Button variant={mode === "study" ? "primary" : "secondary"} onClick={() => setMode("study")} className="text-xs">
            Study
          </Button>
          <Button variant={mode === "print" ? "primary" : "secondary"} onClick={() => setMode("print")} className="text-xs">
            Print
          </Button>
        </div>
      }
    >
      <div className="flex items-center justify-between mb-5">
        <Link href={`/class/${classId}`} className="text-sm text-[var(--teal)] hover:underline">
          ← Back to Class
        </Link>
        <div className="text-xs text-[var(--muted)]">{cls.code}</div>
      </div>

      {mode === "study" ? (
        <div className="max-w-md mx-auto">
          <div className="text-center text-xs text-[var(--muted)] mb-3">
            Card {index + 1} of {total} · Click to flip ·{" "}
            {reversed ? "Showing definition first" : "Showing term first"}
          </div>

          <button
            type="button"
            onClick={() => setFlipped(!flipped)}
            className="w-full min-h-[220px] rounded-2xl border border-[var(--border)] bg-[var(--card)] shadow-md p-8 flex items-center justify-center text-center hover:shadow-lg"
          >
            {!flipped ? (
              <div>
                <div className="text-[10px] uppercase tracking-wide text-[var(--muted)] mb-2">{frontLabel}</div>
                <div className="text-lg font-semibold text-[var(--text)] leading-relaxed">{frontText}</div>
              </div>
            ) : (
              <div>
                <div className="text-[10px] uppercase tracking-wide text-[var(--muted)] mb-2">{backLabel}</div>
                <div className="text-base text-[var(--text)] leading-relaxed">{backText}</div>
              </div>
            )}
          </button>

          <div className="flex justify-between mt-5">
            <Button variant="secondary" onClick={prev}>← Previous</Button>
            <Button onClick={next}>Next →</Button>
          </div>
        </div>
      ) : (
        <div className="max-w-2xl mx-auto">
          <div className="flex justify-between items-center mb-4 print:hidden">
            <p className="text-sm text-[var(--muted)]">Print-friendly list</p>
            <Button onClick={() => window.print()}>Print</Button>
          </div>
          <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl overflow-hidden">
            <div className="px-5 py-3 border-b border-[var(--border)]">
              <h2 className="font-semibold text-sm">{set.name} — Flash Cards</h2>
            </div>
            <div className="divide-y divide-[var(--border)]">
              {cards.map((c, i) => (
                <div key={c.id} className="px-5 py-3.5 grid grid-cols-1 sm:grid-cols-[1fr_2fr] gap-2">
                  <div className="font-semibold text-sm">{i + 1}. {c.term}</div>
                  <div className="text-sm">{c.definition}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
