"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import { getStudySet, getClass } from "@/lib/store";
import type { StudySet, Class, NotesSection } from "@/types";

export default function StudyNotesPage() {
  const params = useParams();
  const router = useRouter();
  const classId = params.id as string;
  const setId = params.setId as string;

  const [set, setSet] = useState<StudySet | null>(null);
  const [cls, setCls] = useState<Class | null>(null);

  useEffect(() => {
    const s = getStudySet(setId);
    const c = getClass(classId);
    if (!s || !c) {
      router.replace("/dashboard");
      return;
    }
    setSet(s);
    setCls(c);
  }, [classId, setId, router]);

  if (!set || !cls) return null;

  const sections = set.notes?.sections || [];

  return (
    <AppShell
      title={`Study Notes – ${set.name}`}
      right={
        <Button variant="secondary" className="text-xs print:hidden" onClick={() => window.print()}>
          Print / Save PDF
        </Button>
      }
    >
      <style jsx global>{`
        @media print {
          aside,
          header,
          .print\\:hidden {
            display: none !important;
          }
          main {
            padding: 0 !important;
            overflow: visible !important;
          }
          body {
            background: white !important;
          }
          .notes-sheet {
            box-shadow: none !important;
            border: none !important;
            max-width: 100% !important;
            padding: 0.5in !important;
          }
          .notes-section {
            break-inside: avoid;
          }
        }
      `}</style>

      <div className="flex items-center justify-between mb-5 print:hidden">
        <Link href={`/class/${classId}`} className="text-sm text-[var(--teal)] hover:underline">
          ← Back to Class
        </Link>
        <div className="flex items-center gap-3">
          <span className="text-xs text-[var(--muted)]">{cls.code}</span>
          <Button variant="secondary" className="text-xs" onClick={() => window.print()}>
            Print / Save PDF
          </Button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto notes-sheet bg-[var(--card)] border border-[var(--border)] rounded-xl p-6 sm:p-8 shadow-sm print:shadow-none print:border-0">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 mb-1">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[var(--muted)]">
            Comprehensive Study Notes
          </span>
          <span className="text-[10px] text-[var(--muted)] shrink-0">Studious AI</span>
        </div>

        <h1 className="text-xl sm:text-2xl font-bold text-[var(--text)] mt-2 leading-tight">
          {set.notes.title}
        </h1>
        <p className="text-sm text-[var(--muted)] mt-1 mb-2">{set.notes.subtitle}</p>
        <p className="text-[11px] text-[var(--muted)] mb-6">
          {cls.code} · {set.name}
          {set.sourceFiles?.length ? ` · Sources: ${set.sourceFiles.join(", ")}` : ""}
        </p>

        <div className="space-y-7">
          {sections.map((sec, i) => (
            <SectionBlock key={i} section={sec} index={i} />
          ))}
        </div>

        {/* Other resources */}
        {set.notes.otherResources?.length > 0 && (
          <div className="mt-8 pt-6 border-t border-[var(--border)] notes-section">
            <h2 className="text-sm font-semibold text-[var(--text)] mb-3">Other Resources</h2>
            <ul className="space-y-1.5">
              {set.notes.otherResources.map((r, i) => (
                <li key={i} className="text-sm text-[var(--text)] flex gap-2">
                  <span className="text-[var(--teal)] shrink-0">→</span>
                  {r.url ? (
                    <a
                      href={r.url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-[var(--teal)] hover:underline"
                    >
                      {r.title}
                    </a>
                  ) : (
                    <span>{r.title}</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Quick links */}
        <div className="flex flex-wrap justify-center gap-3 mt-8 pt-6 border-t border-[var(--border)] print:hidden">
          <Link href={`/class/${classId}/set/${setId}/audio`}>
            <span className="text-sm font-medium text-sky-600 hover:underline">▶ Audio</span>
          </Link>
          <span className="text-[var(--border)]">|</span>
          <Link href={`/class/${classId}/set/${setId}/flashcards`}>
            <span className="text-sm font-medium text-amber-700 hover:underline">Flash Cards</span>
          </Link>
          <span className="text-[var(--border)]">|</span>
          <Link href={`/class/${classId}/set/${setId}/quiz`}>
            <span className="text-sm font-medium text-violet-600 hover:underline">Quiz</span>
          </Link>
        </div>

        {/* Footer logo — last page */}
        <div className="mt-10 pt-6 border-t border-[var(--border)] flex flex-col items-center gap-2">
          <img src="/logo.png" alt="Studious AI" className="h-8 w-auto object-contain" />
          <p className="text-[10px] text-[var(--muted)]">
            Your masterclass for every class · Generated for mastery, not shortcuts
          </p>
        </div>
      </div>
    </AppShell>
  );
}

function SectionBlock({ section, index }: { section: NotesSection; index: number }) {
  const layout = section.layout || (section.table ? "table" : section.columns?.length ? "two-column" : "stack");

  return (
    <div className="notes-section">
      <h2 className="text-sm font-bold text-[var(--text)] mb-2 flex items-baseline gap-2">
        <span className="text-[var(--teal)] text-xs font-semibold">{index + 1}.</span>
        {section.heading}
      </h2>

      {section.body && (
        <p className="text-sm text-[var(--text)] leading-relaxed mb-3">{section.body}</p>
      )}

      {layout === "two-column" && section.columns && section.columns.length >= 2 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {section.columns.map((col, i) => (
            <div
              key={i}
              className="rounded-lg border border-[var(--border)] bg-slate-50/80 dark:bg-slate-800/40 p-3"
            >
              <div className="text-xs font-semibold text-[var(--teal)] mb-2">{col.title}</div>
              <ul className="space-y-1">
                {(col.bullets || []).map((b, j) => (
                  <li key={j} className="text-[13px] text-[var(--text)] flex gap-1.5 leading-snug">
                    <span className="text-[var(--teal)] shrink-0">•</span>
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      ) : layout === "table" && section.table ? (
        <div className="overflow-x-auto rounded-lg border border-[var(--border)]">
          <table className="w-full text-left text-[13px]">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-800 border-b border-[var(--border)]">
                {section.table.headers.map((h, i) => (
                  <th key={i} className="px-3 py-2 font-semibold text-[var(--text)] whitespace-nowrap">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {section.table.rows.map((row, ri) => (
                <tr
                  key={ri}
                  className="border-b border-[var(--border)] last:border-0 odd:bg-[var(--card)] even:bg-slate-50/50 dark:odd:bg-transparent dark:even:bg-slate-800/30"
                >
                  {row.map((cell, ci) => (
                    <td key={ci} className="px-3 py-2 text-[var(--text)] align-top">
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <ul className="space-y-1.5">
          {(section.bullets || []).map((b, j) => (
            <li key={j} className="text-sm text-[var(--text)] flex gap-2 leading-snug">
              <span className="text-[var(--teal)] mt-1 shrink-0">•</span>
              <span>{b}</span>
            </li>
          ))}
        </ul>
      )}

      {/* Also show bullets under table/columns if both provided */}
      {layout !== "stack" && section.bullets && section.bullets.length > 0 && (
        <ul className="space-y-1.5 mt-3">
          {section.bullets.map((b, j) => (
            <li key={j} className="text-sm text-[var(--text)] flex gap-2 leading-snug">
              <span className="text-[var(--teal)] mt-1 shrink-0">•</span>
              <span>{b}</span>
            </li>
          ))}
        </ul>
      )}

      {section.reference && (
        <p className="text-[11px] text-[var(--muted)] mt-2 italic">Source: {section.reference}</p>
      )}
    </div>
  );
}
