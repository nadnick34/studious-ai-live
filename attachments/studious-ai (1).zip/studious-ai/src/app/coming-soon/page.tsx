"use client";

import Link from "next/link";
import { Source_Serif_4 } from "next/font/google";
import { saveUserProfile } from "@/lib/profile";

const serif = Source_Serif_4({
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  style: ["italic", "normal"],
});

export default function ComingSoonPage() {
  return (
    <div className="landing-shell relative min-h-[100dvh] overflow-hidden flex flex-col bg-[var(--slate-dark)] text-[#f4efe6]">
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url('/library-bg.jpg')" }}
        aria-hidden
      />
      <div className="pointer-events-none absolute inset-0 bg-[var(--slate-dark)]/60" aria-hidden />
      <div className="relative z-10 h-1 bg-[var(--teal)]" />

      <main className="relative z-10 flex-1 flex flex-col items-center justify-center text-center px-6 py-10">
        <img src="/hero-mark.png" alt="" className="h-24 w-auto mb-2" />
        <p className={`${serif.className} text-2xl font-semibold`}>Studious AI</p>
        <span className="mt-2 text-[11px] font-semibold tracking-wide uppercase text-[var(--teal)] bg-teal-950/40 border border-teal-700/40 rounded-full px-3 py-1">
          Teacher Edition
        </span>
        <h1 className={`${serif.className} mt-5 text-3xl sm:text-4xl font-semibold max-w-lg`}>
          Coming Soon!
        </h1>
        <p className={`${serif.className} mt-3 text-lg italic text-[var(--teal)]`}>
          Less grading. More time with the student.
        </p>
        <p className="mt-4 max-w-md text-sm text-[#f4efe6]/78 leading-relaxed">
          School-type-aligned assessments, scanned-test grading, and class analytics are on the way.
          Switch back to the Student Edition anytime from the sidebar.
        </p>
        <Link
          href="/dashboard"
          onClick={() => saveUserProfile({ edition: "student" })}
          className="mt-8 inline-flex items-center justify-center rounded-lg bg-[#f4efe6] text-[var(--slate-dark)] px-6 py-3 text-sm font-semibold"
        >
          Back to Student Edition
        </Link>
      </main>
    </div>
  );
}
