"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import SchoolMark from "@/components/SchoolMark";
import { getSessionUser } from "@/lib/auth";
import { fileToDataUrl, getUserProfile, initialsFromName, saveUserProfile, type AccountRole } from "@/lib/profile";
import { brandFromStock, getSavedBrand, saveBrand } from "@/lib/branding";
import { allStock, DEFAULT_BRAND, FALLBACK_PALETTES } from "@/lib/schools";
import { pushProfilePrefs } from "@/lib/profileSync";

export default function ProfilePage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<AccountRole>("student");
  const [phone, setPhone] = useState("");
  const [smsAlerts, setSmsAlerts] = useState(false);
  const [schoolSelect, setSchoolSelect] = useState("studious");
  const [avatar, setAvatar] = useState("");
  const [schoolLogo, setSchoolLogo] = useState("");
  const [customName, setCustomName] = useState("");
  const [paletteId, setPaletteId] = useState("studious");
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  useEffect(() => {
    const u = getSessionUser();
    if (u) {
      setName(u.name);
      setEmail(u.email);
    }
    const p = getUserProfile();
    setRole(p.role);
    setPhone(p.phone);
    setSmsAlerts(p.smsAlerts);
    setSchoolSelect(p.schoolSelect);
    setAvatar(p.avatarDataUrl || "");
    const b = getSavedBrand();
    setSchoolLogo(b.logoUrl || "");
    if (b.kind === "custom") setCustomName(b.name);
  }, []);

  async function onAvatar(file?: File) {
    if (!file) return;
    setAvatar(await fileToDataUrl(file, 240));
  }

  async function onLogo(file?: File) {
    if (!file) return;
    setSchoolLogo(await fileToDataUrl(file, 200));
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaveError(null);
    setSaving(true);
    const profile = saveUserProfile({
      role,
      phone,
      smsAlerts,
      schoolSelect,
      setupComplete: true,
      edition: role === "teacher" ? "teacher" : "student",
      avatarDataUrl: avatar,
    });

    if (schoolSelect === "custom") {
      const pal = FALLBACK_PALETTES.find((p) => p.id === paletteId) || FALLBACK_PALETTES[0];
      saveBrand({
        id: "custom",
        name: customName.trim() || "Custom school",
        location: "",
        kind: "custom",
        primary: pal.primary,
        accent: pal.accent,
        initials: initialsFromName(customName.trim() || "CS"),
        logoUrl: schoolLogo || undefined,
      });
    } else {
      const brand = brandFromStock(schoolSelect) || DEFAULT_BRAND;
      saveBrand({ ...brand, logoUrl: schoolLogo || undefined });
    }

    const user = getSessionUser();
    if (user) {
      const result = await pushProfilePrefs(user.id, { email: user.email, name: user.name });
      setSaving(false);
      if (!result.ok) {
        setSaveError(result.error || "Could not save to your account. Check the extra profile columns in Supabase.");
        return;
      }
    } else {
      setSaving(false);
    }

    if (profile.role === "teacher") router.push("/coming-soon");
    else router.push("/dashboard");
  }

  const initials = initialsFromName(name);

  return (
    <AppShell title="Profile setup">
      <form onSubmit={handleSave} className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-6 max-w-xl space-y-5">
        <div className="flex items-center gap-4">
          <div className="h-16 w-16 rounded-full overflow-hidden bg-[var(--teal)] text-white flex items-center justify-center text-lg font-semibold shrink-0">
            {avatar ? <img src={avatar} alt="" className="h-full w-full object-cover" /> : initials}
          </div>
          <div>
            <label className="block text-xs text-[var(--muted)] mb-1">Profile photo</label>
            <input type="file" accept="image/*" onChange={(e) => onAvatar(e.target.files?.[0])} className="text-xs" />
            {avatar && (
              <button type="button" className="block text-[11px] text-[var(--muted)] mt-1" onClick={() => setAvatar("")}>
                Remove photo
              </button>
            )}
          </div>
        </div>

        <div>
          <label className="block text-xs text-[var(--muted)] mb-1">Name</label>
          <input className="w-full rounded-lg border border-[var(--border)] px-3 py-2 text-sm" value={name} readOnly />
        </div>
        <div>
          <label className="block text-xs text-[var(--muted)] mb-1">Email</label>
          <input className="w-full rounded-lg border border-[var(--border)] px-3 py-2 text-sm" value={email} readOnly />
        </div>

        <div>
          <label className="block text-xs text-[var(--muted)] mb-1">I am a</label>
          <select
            className="w-full rounded-lg border border-[var(--border)] px-3 py-2 text-sm bg-[var(--card)]"
            value={role}
            onChange={(e) => setRole(e.target.value as AccountRole)}
          >
            <option value="student">Student</option>
            <option value="teacher">Teacher</option>
            <option value="both">Student & Teacher</option>
          </select>
        </div>

        <div>
          <label className="block text-xs text-[var(--muted)] mb-1">School</label>
          <select
            className="w-full rounded-lg border border-[var(--border)] px-3 py-2 text-sm bg-[var(--card)]"
            value={schoolSelect}
            onChange={(e) => setSchoolSelect(e.target.value)}
          >
            <option value="studious">Studious default</option>
            <optgroup label="Colleges">
              {allStock()
                .filter((s) => s.kind === "college")
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
            </optgroup>
            <optgroup label="High schools">
              {allStock()
                .filter((s) => s.kind === "high-school")
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
            </optgroup>
            <option value="custom">Custom</option>
          </select>
        </div>

        {schoolSelect === "custom" && (
          <div>
            <label className="block text-xs text-[var(--muted)] mb-1">Custom school name</label>
            <input
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2 text-sm"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              placeholder="School name"
            />
          </div>
        )}

        <div>
          <label className="block text-xs text-[var(--muted)] mb-1">School logo (optional)</label>
          <div className="flex items-center gap-3">
            <SchoolMark
              brand={
                schoolSelect === "custom"
                  ? {
                      ...DEFAULT_BRAND,
                      id: "custom",
                      name: customName || "Custom",
                      initials: initialsFromName(customName || "CS"),
                    }
                  : brandFromStock(schoolSelect) || DEFAULT_BRAND
              }
              logoUrl={schoolLogo || undefined}
            />
            <div>
              <input type="file" accept="image/*" onChange={(e) => onLogo(e.target.files?.[0])} className="text-xs" />
              <p className="text-[11px] text-[var(--muted)] mt-1">Replaces the initials box in the sidebar.</p>
              {schoolLogo && (
                <button type="button" className="text-[11px] text-[var(--muted)]" onClick={() => setSchoolLogo("")}>
                  Remove logo
                </button>
              )}
            </div>
          </div>
        </div>

        {schoolSelect === "custom" && (
          <div>
            <div className="text-xs font-semibold uppercase tracking-wide text-[var(--muted)] mb-2">Color palette</div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {FALLBACK_PALETTES.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPaletteId(p.id)}
                  className={`text-left rounded-lg border p-2 ${
                    paletteId === p.id ? "border-[var(--teal)] ring-1 ring-[var(--teal)]" : "border-[var(--border)]"
                  }`}
                >
                  <div className="flex h-6 rounded overflow-hidden mb-1">
                    <div className="flex-1" style={{ background: p.primary }} />
                    <div className="flex-1" style={{ background: p.accent }} />
                  </div>
                  <div className="text-[11px]">{p.name}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        <div>
          <label className="block text-xs text-[var(--muted)] mb-1">Phone number</label>
          <input
            type="tel"
            className="w-full rounded-lg border border-[var(--border)] px-3 py-2 text-sm"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="(318) 555-0100"
          />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={smsAlerts} onChange={(e) => setSmsAlerts(e.target.checked)} />
          Send me text alerts for upcoming assignments and tests
        </label>

        {saveError && (
          <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{saveError}</div>
        )}
        <Button type="submit" disabled={saving}>
          {saving ? "Saving to your account…" : "Save profile"}
        </Button>
      </form>
    </AppShell>
  );
}
