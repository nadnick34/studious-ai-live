"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import { getAllClassesIncludingArchived, updateClass } from "@/lib/store";
import type { Class } from "@/types";

export default function ArchivedPage() {
  const [classes, setClasses] = useState<Class[]>([]);

  function refresh() {
    setClasses(getAllClassesIncludingArchived().filter((c) => c.archived));
  }

  useEffect(() => {
    refresh();
  }, []);

  function restore(c: Class) {
    updateClass(c.id, { archived: false });
    refresh();
  }

  return (
    <AppShell title="Archived classes">
      {classes.length === 0 ? (
        <div className="text-center py-16 text-[var(--muted)] text-sm">
          No archived classes. Archive a class from My Classes when you’re done with it.
        </div>
      ) : (
        <div className="space-y-3 max-w-2xl">
          {classes.map((c) => (
            <div
              key={c.id}
              className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div>
                <div className="text-xs font-semibold text-[var(--muted)]">{c.code}</div>
                <div className="font-medium text-[var(--text)]">{c.name}</div>
                <div className="text-xs text-[var(--muted)]">{c.subject}</div>
              </div>
              <div className="flex gap-2">
                <Link href={`/class/${c.id}`}>
                  <Button variant="secondary" className="text-xs">
                    Open
                  </Button>
                </Link>
                <Button className="text-xs" onClick={() => restore(c)}>
                  Restore
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}
