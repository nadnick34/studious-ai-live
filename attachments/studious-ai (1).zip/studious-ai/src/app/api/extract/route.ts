import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const files = form.getAll("files");
    if (!files.length) {
      return NextResponse.json({ text: "", fileCount: 0, notes: [] });
    }

    const parts: string[] = [];
    const notes: string[] = [];

    for (const item of files) {
      if (!(item instanceof File)) continue;
      const name = item.name || "upload";
      const type = item.type || "";
      const buf = Buffer.from(await item.arrayBuffer());
      const lower = name.toLowerCase();

      if (
        type.startsWith("text/") ||
        lower.endsWith(".txt") ||
        lower.endsWith(".md") ||
        lower.endsWith(".csv") ||
        lower.endsWith(".json")
      ) {
        const text = buf.toString("utf8");
        parts.push(`\n\n===== SOURCE: ${name} =====\n${text}`);
        notes.push(`${name}: ${text.length} characters`);
        continue;
      }

      if (type === "application/pdf" || lower.endsWith(".pdf")) {
        try {
          const text = await extractPdf(buf);
          if (text.trim()) {
            parts.push(`\n\n===== SOURCE: ${name} =====\n${text}`);
            notes.push(`${name}: extracted ${text.length} characters from PDF`);
          } else {
            parts.push(
              `\n\n===== SOURCE: ${name} =====\n[PDF had little or no extractable text. It may be scanned. Treat the filename and any visible headings as context.]`
            );
            notes.push(`${name}: PDF had no extractable text (possible scan)`);
          }
        } catch (err) {
          parts.push(
            `\n\n===== SOURCE: ${name} =====\n[Could not parse this PDF: ${err instanceof Error ? err.message : "parse error"}]`
          );
          notes.push(`${name}: PDF parse error`);
        }
        continue;
      }

      if (type.startsWith("image/") || /\.(png|jpe?g|gif|webp)$/i.test(name)) {
        parts.push(
          `\n\n===== SOURCE: ${name} =====\n[Image uploaded (${Math.round(buf.length / 1024)} KB). Use the filename and typical lecture-note structure. If this is handwritten notes or a slide, reconstruct likely headings and terms from the set name and any other sources.]`
        );
        notes.push(`${name}: image recorded`);
        continue;
      }

      parts.push(
        `\n\n===== SOURCE: ${name} =====\n[File recorded: ${name}, type ${type || "unknown"}, ${Math.round(buf.length / 1024)} KB.]`
      );
      notes.push(`${name}: binary recorded`);
    }

    return NextResponse.json({
      text: parts.join("\n").trim(),
      fileCount: files.length,
      notes,
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Extract failed" },
      { status: 500 }
    );
  }
}

async function extractPdf(buf: Buffer): Promise<string> {
  const { extractText, getDocumentProxy } = await import("unpdf");
  const pdf = await getDocumentProxy(new Uint8Array(buf));
  const result = await extractText(pdf, { mergePages: true });
  const text = Array.isArray(result.text) ? result.text.join("\n") : result.text;
  return (text || "").toString();
}
