import { NextRequest, NextResponse } from "next/server";
import { buildProfessorInsightPrompt } from "@/lib/prompts";

export const runtime = "nodejs";
export const maxDuration = 45;

async function fetchText(url: string): Promise<string> {
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "StudiousAI/1.0 (student briefing; +https://getstudious.ai)",
        Accept: "application/json,text/html",
      },
    });
    if (!res.ok) return "";
    return await res.text();
  } catch {
    return "";
  }
}

async function openAlexSnippets(name: string, school: string): Promise<string> {
  const q = encodeURIComponent(name);
  const url = `https://api.openalex.org/authors?search=${q}&per-page=5`;
  const raw = await fetchText(url);
  if (!raw) return "";
  try {
    const data = JSON.parse(raw);
    const rows = data?.results || [];
    return rows
      .slice(0, 5)
      .map((a: { display_name?: string; last_known_institutions?: { display_name?: string }[]; cited_by_count?: number }) => {
        const inst = (a.last_known_institutions || []).map((i) => i.display_name).join(", ");
        return `${a.display_name} — ${inst || "institution unknown"} (citations ${a.cited_by_count ?? "?"})`;
      })
      .join("\n");
  } catch {
    return "";
  }
}

async function duckDuckGo(query: string): Promise<string> {
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  const html = await fetchText(url);
  if (!html) return "";
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 2500);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const professorName = (body.professorName || "").toString().trim();
    if (!professorName) {
      return NextResponse.json({ error: "professorName is required" }, { status: 400 });
    }

    const schoolName = (body.schoolName || "").toString().trim();
    const subject = (body.subject || "").toString().trim();
    const courseCode = (body.courseCode || "").toString().trim();

    const [alex, ddg1, ddg2, ddg3] = await Promise.all([
      openAlexSnippets(professorName, schoolName),
      duckDuckGo(`"${professorName}" "${schoolName}" professor ${subject}`),
      duckDuckGo(`site:ratemyprofessors.com "${professorName}" ${schoolName}`),
      duckDuckGo(`"${professorName}" ${schoolName} faculty directory`),
    ]);

    const research = [
      alex && `PUBLICATIONS / OPENALEX:\n${alex}`,
      ddg1 && `WEB:\n${ddg1}`,
      ddg2 && `RATE MY PROFESSORS SEARCH:\n${ddg2}`,
      ddg3 && `FACULTY SEARCH:\n${ddg3}`,
    ]
      .filter(Boolean)
      .join("\n\n---\n\n");

    const { system, user } = buildProfessorInsightPrompt({
      professorName,
      schoolName,
      subject,
      courseCode,
    });

    const key = process.env.GROK_API_KEY || process.env.XAI_API_KEY;
    if (!key) {
      return NextResponse.json({
        found: false,
        summary: "Connect GROK_API_KEY to look up this instructor from public sources.",
        teachingStyle: "unknown",
        difficulty: "unknown",
        tips: ["Check the department directory and syllabus."],
        sources: [],
      });
    }

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "grok-3",
        messages: [
          { role: "system", content: system },
          {
            role: "user",
            content:
              user +
              "\n\nMatch ONLY on NAME + the SCHOOL entered. Do not use Wikipedia. " +
              "If the person is at a different school, found=false.\n\n" +
              (research || "No live snippets. If you cannot place this person at the entered school, found=false."),
          },
        ],
        temperature: 0.2,
        max_tokens: 1800,
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      return NextResponse.json(
        { error: `Lookup failed (${res.status}): ${text.slice(0, 200)}` },
        { status: 502 }
      );
    }

    const data = await res.json();
    let content = data.choices?.[0]?.message?.content || "";
    content = content.replace(/^```json\s*/i, "").replace(/```[\s]*$/i, "").trim();
    const start = content.indexOf("{");
    const end = content.lastIndexOf("}");
    if (start >= 0 && end > start) content = content.slice(start, end + 1);

    let parsed: {
      found?: boolean;
      summary?: string;
      teachingStyle?: string;
      difficulty?: string;
      tips?: string[];
      sources?: string[];
    };
    try {
      parsed = JSON.parse(content);
    } catch {
      parsed = {
        found: Boolean(research),
        summary:
          content.slice(0, 600) ||
          "Public faculty sources were found. Save the class and try insight again if this looks incomplete.",
        teachingStyle: "unknown",
        difficulty: "unknown",
        tips: [],
        sources: ["Grok public knowledge"],
      };
    }

    if (!parsed.summary && research) {
      parsed.found = true;
      parsed.summary = research.replace(/\s+/g, " ").slice(0, 500);
    }
    if (!parsed.found && parsed.summary && !/could not|not found|unknown instructor/i.test(parsed.summary)) {
      parsed.found = true;
    }
    return NextResponse.json(parsed);
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Professor lookup failed" },
      { status: 500 }
    );
  }
}
