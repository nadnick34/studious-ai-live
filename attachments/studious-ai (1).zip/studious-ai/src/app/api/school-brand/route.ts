import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 30;

async function wikiLogo(query: string): Promise<string | undefined> {
  try {
    const url =
      "https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&utf8=1&srlimit=3&srsearch=" +
      encodeURIComponent(query);
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    if (!res.ok) return;
    const data = await res.json();
    const title = data?.query?.search?.[0]?.title;
    if (!title) return;
    const sum = await fetch(
      "https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(title.replace(/ /g, "_"))
    );
    if (!sum.ok) return;
    const s = await sum.json();
    return s?.thumbnail?.source as string | undefined;
  } catch {
    return;
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name || "").trim();
    const city = String(body.city || "").trim();
    const state = String(body.state || "").trim();
    if (!name) {
      return NextResponse.json({ error: "School name is required" }, { status: 400 });
    }

    const query = [name, city, state, "high school OR university colors"].filter(Boolean).join(" ");
    const logoUrl = await wikiLogo([name, city, state].filter(Boolean).join(" "));

    const key = process.env.GROK_API_KEY || process.env.XAI_API_KEY;
    if (!key) {
      return NextResponse.json({
        found: Boolean(logoUrl),
        name,
        location: [city, state].filter(Boolean).join(", "),
        logoUrl,
        primary: null,
        accent: null,
        note: "No API key — pick a palette below, or add GROK_API_KEY for a color lookup.",
      });
    }

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "grok-3",
        messages: [
          {
            role: "system",
            content: `Identify official or commonly used school colors for this exact school (name + city + state).
Do not return a similarly named school in another city.
Return JSON only:
{ "found": true|false, "name": "string", "location": "string", "primary": "#RRGGBB or null", "accent": "#RRGGBB or null", "mascot": "string or empty" }
primary = main brand/jersey color. accent = darker sidebar color.`,
          },
          { role: "user", content: query },
        ],
        temperature: 0.1,
        max_tokens: 400,
      }),
    });

    if (!res.ok) {
      return NextResponse.json({
        found: Boolean(logoUrl),
        name,
        location: [city, state].filter(Boolean).join(", "),
        logoUrl,
        primary: null,
        accent: null,
      });
    }

    const data = await res.json();
    let content = data.choices?.[0]?.message?.content || "";
    content = content.replace(/^```json\s*/i, "").replace(/```[\s]*$/i, "").trim();
    const start = content.indexOf("{");
    const end = content.lastIndexOf("}");
    if (start >= 0 && end > start) content = content.slice(start, end + 1);
    const parsed = JSON.parse(content);
    return NextResponse.json({
      ...parsed,
      logoUrl: logoUrl || parsed.logoUrl,
      name: parsed.name || name,
      location: parsed.location || [city, state].filter(Boolean).join(", "),
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Lookup failed" },
      { status: 500 }
    );
  }
}
