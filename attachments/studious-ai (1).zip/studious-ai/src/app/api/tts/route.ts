import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 60;

/**
 * POST /api/tts
 * Prefers xAI Grok TTS (GROK_API_KEY / XAI_API_KEY).
 * Falls back to OpenAI TTS if OPENAI_API_KEY is set and Grok is unavailable.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const text = (body.text || "").toString().trim();
    if (!text) {
      return NextResponse.json({ error: "text is required" }, { status: 400 });
    }

    const input = text.slice(0, 14000);
    const grokKey = process.env.GROK_API_KEY || process.env.XAI_API_KEY;
    const openaiKey = process.env.OPENAI_API_KEY || process.env.TTS_API_KEY;

    if (grokKey) {
      const requested = (body.voice || process.env.GROK_TTS_VOICE || "eve").toString().toLowerCase();
      const grokVoices = ["eve", "ara", "rex", "sal", "leo"];
      const voice = grokVoices.includes(requested) ? requested : "eve";
      const res = await fetch("https://api.x.ai/v1/tts", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${grokKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: input,
          voice_id: voice,
          language: "en",
          output_format: {
            codec: "mp3",
            sample_rate: 24000,
            bit_rate: 128000,
          },
        }),
      });

      if (res.ok) {
        const buffer = Buffer.from(await res.arrayBuffer());
        return new NextResponse(buffer, {
          status: 200,
          headers: {
            "Content-Type": "audio/mpeg",
            "Cache-Control": "private, max-age=3600",
          },
        });
      }

      const errText = await res.text();
      // If OpenAI is also configured, try it; otherwise return Grok error
      if (!openaiKey) {
        return NextResponse.json(
          { error: `Grok TTS failed (${res.status}): ${errText.slice(0, 240)}` },
          { status: 502 }
        );
      }
    }

    if (openaiKey) {
      const voice = (body.voice || "alloy").toString();
      const base = process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";
      const res = await fetch(`${base}/audio/speech`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${openaiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: process.env.TTS_MODEL || "tts-1",
          voice,
          input: input.slice(0, 4000),
          response_format: "mp3",
        }),
      });

      if (!res.ok) {
        const errText = await res.text();
        return NextResponse.json(
          { error: `TTS failed (${res.status}): ${errText.slice(0, 200)}` },
          { status: 502 }
        );
      }

      const buffer = Buffer.from(await res.arrayBuffer());
      return new NextResponse(buffer, {
        status: 200,
        headers: {
          "Content-Type": "audio/mpeg",
          "Cache-Control": "private, max-age=3600",
        },
      });
    }

    return NextResponse.json(
      {
        error:
          "No TTS key configured. Add GROK_API_KEY (xAI) in Vercel Environment Variables.",
      },
      { status: 503 }
    );
  } catch (err) {
    console.error("[/api/tts]", err);
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "TTS error" },
      { status: 500 }
    );
  }
}
