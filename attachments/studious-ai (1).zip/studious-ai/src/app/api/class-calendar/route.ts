import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 45;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const syllabusText = String(body.syllabusText || "");
    const notesText = String(body.notesText || "");
    const className = String(body.className || "this class");
    const semester = String(body.semester || "");
    const today = new Date().toISOString().slice(0, 10);

    if (!syllabusText.trim() && !notesText.trim()) {
      return NextResponse.json({ alerts: [], upcoming: [] });
    }

    const key = process.env.GROK_API_KEY || process.env.XAI_API_KEY;
    if (!key) {
      return NextResponse.json({
        alerts: [
          {
            id: "a1",
            kind: "policy",
            message: "Connect GROK_API_KEY to pull due dates from the syllabus.",
          },
        ],
        upcoming: [],
      });
    }

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "grok-3",
        messages: [
          {
            role: "system",
            content: `Extract student-facing alerts and upcoming work from a syllabus and class notes.
Today is ${today}. Semester context: ${semester || "unspecified"}.
Return JSON only:
{
  "alerts": [{ "id": "a1", "kind": "due-soon|exam|reading|policy", "message": "short notice" }],
  "upcoming": [{ "id": "u1", "type": "assignment|exam|quiz|reading|other", "title": "string", "date": "YYYY-MM-DD or empty", "note": "optional" }]
}
Rules:
- Prefer real dates from the source. If only a week number is given, estimate using the semester if possible.
- Alerts: overdue, due within 10 days, exams, required readings, important policies.
- Upcoming: next 6–10 items in date order.
- Do not invent assignments that are not in the sources.`,
          },
          {
            role: "user",
            content: `Class: ${className}\n\nSYLLABUS:\n${syllabusText.slice(0, 18000)}\n\nNOTES:\n${notesText.slice(0, 8000)}`,
          },
        ],
        temperature: 0.1,
        max_tokens: 2000,
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      return NextResponse.json(
        { error: `Calendar parse failed (${res.status}): ${text.slice(0, 200)}` },
        { status: 502 }
      );
    }

    const data = await res.json();
    let content = data.choices?.[0]?.message?.content || "";
    content = content.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
    const parsed = JSON.parse(content);
    return NextResponse.json({
      alerts: parsed.alerts || [],
      upcoming: parsed.upcoming || [],
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Calendar parse failed" },
      { status: 500 }
    );
  }
}
