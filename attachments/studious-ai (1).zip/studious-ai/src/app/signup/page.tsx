"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { signUp } from "@/lib/auth";
import Button from "@/components/Button";
import PublicTheme from "@/components/PublicTheme";

export default function SignUpPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const result = await signUp({ name, email, password });
    setLoading(false);
    if (result.error) {
      setError(result.error);
      return;
    }
    router.push("/profile");
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#2c3a47] px-4">
      <PublicTheme />
      <div className="w-full max-w-[380px] bg-[var(--card)] rounded-2xl shadow-lg border border-[var(--border)] p-8">
        <div className="flex flex-col items-center mb-6">
          <img src="/logo.png" alt="Studious AI" className="h-10 w-auto object-contain" />
          <p className="text-xs text-[var(--muted)] mt-1">Create your account</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-medium text-[var(--muted)] mb-1">Full name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5 text-sm outline-none focus:border-[var(--teal)]"
              required
              autoComplete="name"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--muted)] mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5 text-sm outline-none focus:border-[var(--teal)]"
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--muted)] mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5 text-sm outline-none focus:border-[var(--teal)]"
              required
              minLength={6}
              autoComplete="new-password"
            />
            <p className="text-[10px] text-[var(--muted)] mt-1">At least 6 characters</p>
          </div>

          {error && (
            <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full mt-2" disabled={loading}>
            {loading ? "Creating account…" : "Create account"}
          </Button>
        </form>

        <p className="text-center text-xs text-[var(--muted)] mt-5">
          Already have an account?{" "}
          <Link href="/login" className="text-[var(--teal)] font-medium hover:underline">
            Sign in
          </Link>
        </p>
        <p className="text-center text-xs text-[var(--muted)] mt-4">
          <Link href="/" className="hover:underline">
            ← Back to home
          </Link>
        </p>
      </div>
    </div>
  );
}
