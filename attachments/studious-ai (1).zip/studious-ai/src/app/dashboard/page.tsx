"use client";

import { useEffect, useState, useRef } from "react";
import Link from "next/link";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import { getClasses, addClass, updateClass, getStudySetsForClass } from "@/lib/store";
import { getSessionUser } from "@/lib/auth";
import { syncUserData } from "@/lib/sync";
import type { Class } from "@/types";
import { parseSyllabusLocally } from "@/lib/calendar";

function formatShortDate(value: string) {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) {
    const m = value.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!m) return value;
    return `${m[2]}/${m[3]}/${m[1].slice(2)}`;
  }
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const yy = String(d.getFullYear()).slice(2);
  return `${mm}/${dd}/${yy}`;
}

function timeAgo(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const hours = Math.floor(diff / 3600000);
  if (hours < 1) return "Just now";
  if (hours < 24) return `${hours} hour${hours > 1 ? "s" : ""} ago`;
  const days = Math.floor(hours / 24);
  if (days === 1) return "Yesterday";
  return `${days} days ago`;
}

const emptyForm = {
  name: "",
  code: "",
  subject: "",
  schoolName: "",
  semester: "",
  professorName: "",
  professorInsight: "",
  textbook: "",
  textbookAuthor: "",
  scheduleDays: "",
  scheduleTime: "",
  syllabusFile: "",
  syllabusText: "",
  miscNotes: "",
};

export default function DashboardPage() {
  const [classes, setClasses] = useState<Class[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Class | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [insightLoading, setInsightLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [syllabusBlob, setSyllabusBlob] = useState<File | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  function refresh() {
    setClasses(getClasses());
  }

  useEffect(() => {
    refresh();
    const user = getSessionUser();
    if (user?.id) {
      syncUserData(user.id)
        .then(() => refresh())
        .catch(() => {});
    }
  }, []);

  function setField(key: keyof typeof emptyForm, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setSyllabusBlob(null);
    setShowForm(true);
  }

  function openEdit(c: Class, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    setEditing(c);
    setForm({
      name: c.name || "",
      code: c.code || "",
      subject: c.subject || "",
      schoolName: c.schoolName || "",
      semester: c.semester || "",
      professorName: c.professorName || "",
      professorInsight: c.professorInsight || "",
      textbook: c.textbook || "",
      textbookAuthor: c.textbookAuthor || "",
      scheduleDays: c.scheduleDays || "",
      scheduleTime: c.scheduleTime || "",
      syllabusFile: c.syllabusFile || "",
      syllabusText: c.syllabusText || "",
      miscNotes: c.miscNotes || "",
    });
    setSyllabusBlob(null);
    setShowForm(true);
  }

  function handleArchive(c: Class, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm(`Archive “${c.code} – ${c.name}”?`)) return;
    updateClass(c.id, { archived: true });
    refresh();
  }

  async function scanClass(c: Class, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    const notesText = getStudySetsForClass(c.id)
      .map((s) => [s.name, ...(s.notes?.sections || []).flatMap((sec) => [sec.heading, ...(sec.bullets || [])])].join("\n"))
      .join("\n");
    const source = [c.syllabusText || "", notesText, c.miscNotes || ""].join("\n");
    if (!source.trim()) {
      alert("Upload or paste a syllabus first (Edit → Syllabus), then click Scan.");
      openEdit(c, e);
      return;
    }
    const local = parseSyllabusLocally(source);
    let alerts = local.alerts;
    let upcoming = local.upcoming;
    try {
      const cal = await fetch("/api/class-calendar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          className: `${c.code} ${c.name}`,
          semester: c.semester || "",
          syllabusText: c.syllabusText || "",
          notesText,
        }),
      });
      if (cal.ok) {
        const parsed = await cal.json();
        if (parsed.alerts?.length) alerts = parsed.alerts;
        if (parsed.upcoming?.length) upcoming = parsed.upcoming;
      }
    } catch {
      /* use local parse */
    }
    updateClass(c.id, { alerts, upcoming });
    refresh();
  }

  async function fetchProfessorInsight() {
    if (!form.professorName.trim()) return;
    setInsightLoading(true);
    try {
      const res = await fetch("/api/professor-insight", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          professorName: form.professorName.trim(),
          schoolName: form.schoolName.trim(),
          subject: form.subject.trim(),
          courseCode: form.code.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Lookup failed");
      const parts = [
        data.summary,
        data.teachingStyle && data.teachingStyle !== "unknown" ? `Style: ${data.teachingStyle}` : "",
        data.difficulty && data.difficulty !== "unknown" ? `Difficulty: ${data.difficulty}` : "",
        Array.isArray(data.tips) && data.tips.length ? "Tips: " + data.tips.join(" ") : "",
        Array.isArray(data.sources) && data.sources.length ? "Sources: " + data.sources.join("; ") : "",
      ].filter(Boolean);
      setForm((f) => ({ ...f, professorInsight: parts.join(" ") }));
    } catch (err) {
      setForm((f) => ({
        ...f,
        professorInsight:
          err instanceof Error ? err.message : "Could not look up this professor.",
      }));
    } finally {
      setInsightLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) return;
    setSaving(true);

    let syllabusText = (form.syllabusText || editing?.syllabusText || "").trim();
    let alerts = editing?.alerts;
    let upcoming = editing?.upcoming;

    try {
      if (syllabusBlob) {
        const formData = new FormData();
        formData.append("files", syllabusBlob);
        const extracted = await fetch("/api/extract", { method: "POST", body: formData });
        const extractedJson = await extracted.json().catch(() => ({}));
        if (extracted.ok && extractedJson.text) {
          syllabusText = extractedJson.text;
        }
      }

      const notesText = (editing ? getStudySetsForClass(editing.id) : [])
        .map((s) => [s.name, s.notes?.title, ...(s.notes?.sections || []).flatMap((sec) => [sec.heading, ...(sec.bullets || [])])].join("\n"))
        .join("\n\n");

      const source = [syllabusText, notesText, form.miscNotes].filter(Boolean).join("\n");
      const local = parseSyllabusLocally(source);
      alerts = local.alerts.length ? local.alerts : alerts;
      upcoming = local.upcoming.length ? local.upcoming : upcoming;

      if (source.trim()) {
        const cal = await fetch("/api/class-calendar", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            className: `${form.code} ${form.name}`.trim(),
            semester: form.semester,
            syllabusText: syllabusText || "",
            notesText,
          }),
        });
        if (cal.ok) {
          const parsed = await cal.json();
          if (parsed.alerts?.length) alerts = parsed.alerts;
          if (parsed.upcoming?.length) upcoming = parsed.upcoming;
        }
      }
    } catch {
      /* keep class even if calendar parse fails */
    }

    const payload = {
      name: form.name.trim(),
      code: form.code.trim() || "NEW",
      subject: form.subject.trim() || "General",
      schoolName: form.schoolName.trim() || undefined,
      semester: form.semester.trim() || undefined,
      professorName: form.professorName.trim() || undefined,
      professorInsight: form.professorInsight.trim() || undefined,
      textbook: form.textbook.trim() || undefined,
      textbookAuthor: form.textbookAuthor.trim() || undefined,
      scheduleDays: form.scheduleDays.trim() || undefined,
      scheduleTime: form.scheduleTime.trim() || undefined,
      syllabusFile: form.syllabusFile || undefined,
      syllabusText,
      miscNotes: form.miscNotes.trim() || undefined,
      alerts,
      upcoming,
    };

    if (editing) {
      updateClass(editing.id, payload);
    } else {
      addClass(payload);
    }
    setSaving(false);
    refresh();
    setShowForm(false);
    setEditing(null);
    setSyllabusBlob(null);
  }

  return (
    <AppShell
      title="My Classes"
      right={
        <Button onClick={openCreate} className="text-xs sm:text-sm">
          + New Class
        </Button>
      }
    >
      {classes.length === 0 ? (
        <div className="text-center py-16 px-4">
          <p className="text-[var(--muted)] mb-4">No classes yet. Create your first class to get started.</p>
          <Button onClick={openCreate}>+ New Class</Button>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {classes.map((c) => (
            <div
              key={c.id}
              className="bg-[var(--card)] border border-[var(--border)] rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow relative group"
            >
              <Link href={`/class/${c.id}`} className="block">
                <div className="text-xs font-semibold text-[var(--teal)] mb-1">{c.code}</div>
                <div className="font-semibold text-[var(--text)] mb-1 pr-16">{c.name}</div>
                <div className="text-xs text-[var(--muted)] space-y-0.5">
                  {c.subject && <div>{c.subject}</div>}
                  {c.professorName && (
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span>Prof. {c.professorName}</span>
                      {c.professorInsight && (
                        <span
                          title={c.professorInsight}
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            alert(c.professorInsight);
                          }}
                          className="inline-flex items-center justify-center w-4 h-4 rounded-full bg-teal-50 text-[var(--teal)] border border-teal-200 cursor-pointer hover:bg-teal-100"
                          aria-label="Professor insight"
                        >
                          <svg className="w-2.5 h-2.5" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                          </svg>
                        </span>
                      )}
                    </div>
                  )}
                  {(c.scheduleDays || c.scheduleTime) && (
                    <div>
                      {[c.scheduleDays, c.scheduleTime].filter(Boolean).join(" · ")}
                    </div>
                  )}
                  {c.semester && <div>{c.semester}</div>}
                  {c.schoolName && <div>{c.schoolName}</div>}
                  {c.textbook && (
                    <div className="truncate">
                      {c.textbook}
                      {c.textbookAuthor ? ` — ${c.textbookAuthor}` : ""}
                    </div>
                  )}
                </div>
                {(c.alerts && c.alerts.length > 0) && (
                  <div className="mt-3 space-y-1">
                    {c.alerts.slice(0, 3).map((a) => (
                      <div
                        key={a.id}
                        className="text-[11px] leading-snug rounded-md px-2 py-1.5 bg-amber-50 text-amber-900 border border-amber-200"
                      >
                        {a.message}
                      </div>
                    ))}
                  </div>
                )}
                {(c.upcoming && c.upcoming.length > 0) && (
                  <div className="mt-3">
                    <div className="text-[10px] uppercase tracking-wide font-semibold text-[var(--teal)] mb-1">
                      Upcoming
                    </div>
                    <ul className="space-y-1">
                      {c.upcoming.slice(0, 4).map((u) => (
                        <li key={u.id} className="text-[11px] text-[var(--text)] flex justify-between gap-2">
                          <span className="truncate">
                            <span className="text-[var(--muted)] capitalize">{u.type}</span>
                            {" · "}
                            {u.title}
                          </span>
                          {u.date && (
                            <span className="shrink-0 text-[var(--muted)]">{formatShortDate(u.date)}</span>
                          )}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <div className="text-[10px] text-[var(--muted)] mt-3">
                  Last opened {timeAgo(c.lastAccessed)}
                </div>
              </Link>
              <div className="absolute top-3 right-3 flex gap-1">
                <button
                  type="button"
                  onClick={(e) => openEdit(c, e)}
                  className="text-[11px] px-2 py-1 rounded-md border border-[var(--teal)] text-[var(--teal)] bg-[var(--card)]"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={(e) => handleArchive(c, e)}
                  className="text-[11px] px-2 py-1 rounded-md border border-[var(--border)] text-[var(--muted)] bg-[var(--card)]"
                >
                  Archive
                </button>
              </div>
              {(!c.upcoming || c.upcoming.length === 0) && (
                <p className="text-[10px] text-[var(--muted)] mt-2 pr-28">
                  No upcoming items yet. Edit the class and add a syllabus, then save.
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black/40 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
          <div className="bg-[var(--card)] rounded-t-2xl sm:rounded-xl shadow-xl w-full sm:max-w-lg p-6 max-h-[92vh] overflow-y-auto">
            <h3 className="text-base font-semibold mb-4 text-[var(--text)]">
              {editing ? "Edit class" : "New class"}
            </h3>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Field label="Class name *" value={form.name} onChange={(v) => setField("name", v)} required placeholder="Principles of Biology" />
                <Field label="Course code" value={form.code} onChange={(v) => setField("code", v)} placeholder="BIOL 1543" />
                <Field label="Subject" value={form.subject} onChange={(v) => setField("subject", v)} placeholder="Biology" />
                <Field label="School" value={form.schoolName} onChange={(v) => setField("schoolName", v)} placeholder="University of Arkansas" />
                <Field label="Semester / quarter" value={form.semester} onChange={(v) => setField("semester", v)} placeholder="Fall 2026" />
                <Field label="Days" value={form.scheduleDays} onChange={(v) => setField("scheduleDays", v)} placeholder="MWF" />
                <Field label="Time" value={form.scheduleTime} onChange={(v) => setField("scheduleTime", v)} placeholder="10:00–10:50 AM" />
                <div className="sm:col-span-2">
                  <Field label="Professor" value={form.professorName} onChange={(v) => setField("professorName", v)} placeholder="Dr. Sarah Mitchell" />
                  <button
                    type="button"
                    onClick={fetchProfessorInsight}
                    disabled={insightLoading || !form.professorName.trim()}
                    className="mt-1 text-xs text-[var(--teal)] hover:underline disabled:opacity-50"
                  >
                    {insightLoading ? "Looking up insight…" : "Get professor insight"}
                  </button>
                  {form.professorInsight && (
                    <p className="mt-2 text-[11px] text-[var(--muted)] leading-relaxed border border-[var(--border)] rounded-lg px-2.5 py-2 bg-slate-50 dark:bg-slate-800/40 dark:bg-slate-800/50">
                      {form.professorInsight}
                    </p>
                  )}
                </div>
                <Field label="Textbook" value={form.textbook} onChange={(v) => setField("textbook", v)} placeholder="Give Me Liberty!" />
                <Field label="Textbook author" value={form.textbookAuthor} onChange={(v) => setField("textbookAuthor", v)} placeholder="Eric Foner" />
              </div>

              <div>
                <label className="block text-xs font-medium text-[var(--muted)] mb-1">Syllabus</label>
                <div className="flex items-center gap-2">
                  <Button type="button" variant="secondary" className="text-xs" onClick={() => fileRef.current?.click()}>
                    Upload syllabus
                  </Button>
                  <span className="text-xs text-[var(--muted)] truncate">
                    {form.syllabusFile || "No file selected — used for alerts and upcoming"}
                  </span>
                  <input
                    ref={fileRef}
                    type="file"
                    accept=".pdf,.doc,.docx,.png,.jpg,.txt"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) {
                        setField("syllabusFile", f.name);
                        setSyllabusBlob(f);
                      }
                    }}
                  />
                </div>
                <textarea
                  value={form.syllabusText}
                  onChange={(e) => setField("syllabusText", e.target.value)}
                  rows={4}
                  className="mt-2 w-full rounded-lg border border-[var(--border)] bg-[var(--card)] px-3 py-2 text-sm outline-none focus:border-[var(--teal)] text-[var(--text)]"
                  placeholder="Or paste syllabus text here (due dates, exams, readings)…"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[var(--muted)] mb-1">Misc notes</label>
                <textarea
                  value={form.miscNotes}
                  onChange={(e) => setField("miscNotes", e.target.value)}
                  rows={2}
                  className="w-full rounded-lg border border-[var(--border)] bg-[var(--card)] px-3 py-2 text-sm outline-none focus:border-[var(--teal)] text-[var(--text)]"
                  placeholder="Attendance policy, exam style, tips…"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="secondary" onClick={() => { setShowForm(false); setEditing(null); }}>
                  Cancel
                </Button>
                <Button type="submit" disabled={saving}>
                  {saving ? "Saving…" : editing ? "Save changes" : "Create class"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AppShell>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-[var(--muted)] mb-1">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        className="w-full rounded-lg border border-[var(--border)] bg-[var(--card)] px-3 py-2 text-sm outline-none focus:border-[var(--teal)] text-[var(--text)]"
      />
    </div>
  );
}
