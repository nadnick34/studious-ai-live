"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AppShell from "@/components/AppShell";
import Button from "@/components/Button";
import { getSessionUser, listUsers, setUserRole, signOut } from "@/lib/auth";
import type { User, UserRole } from "@/types";

export default function AdminPage() {
  const router = useRouter();
  const [users, setUsers] = useState<User[]>([]);
  const [me, setMe] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);

  async function refresh() {
    const list = await listUsers();
    setUsers(list);
  }

  useEffect(() => {
    const u = getSessionUser();
    if (!u) {
      router.replace("/");
      return;
    }
    if (u.role !== "admin") {
      router.replace("/dashboard");
      return;
    }
    setMe(u);
    refresh().finally(() => setLoading(false));
  }, [router]);

  async function changeRole(userId: string, role: UserRole) {
    const res = await setUserRole(userId, role);
    if (res.error) {
      setMsg(res.error);
      return;
    }
    setMsg(`Updated role to ${role}`);
    await refresh();
  }

  if (loading || !me) {
    return (
      <div className="min-h-screen flex items-center justify-center text-sm text-[var(--muted)]">
        Loading…
      </div>
    );
  }

  return (
    <AppShell title="Admin">
      <div className="mb-6">
        <h2 className="text-lg font-bold text-[var(--text)]">User management</h2>
        <p className="text-sm text-[var(--muted)] mt-1">
          Signed in as {me.email}. All accounts on this deployment are listed below.
        </p>
      </div>

      {msg && (
        <div className="mb-4 text-sm text-[var(--teal)] bg-teal-50 border border-teal-100 rounded-lg px-3 py-2">
          {msg}
        </div>
      )}

      <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/40 border-b border-[var(--border)] text-left text-xs font-semibold uppercase tracking-wide text-[var(--muted)]">
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Email</th>
              <th className="px-4 py-3">Role</th>
              <th className="px-4 py-3">Created</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-b border-[var(--border)] last:border-0">
                <td className="px-4 py-3 font-medium">{u.name}</td>
                <td className="px-4 py-3 text-[var(--muted)]">{u.email}</td>
                <td className="px-4 py-3">
                  <span
                    className={`text-xs font-semibold px-2 py-0.5 rounded ${
                      u.role === "admin"
                        ? "bg-amber-50 text-amber-800"
                        : "bg-slate-100 text-slate-700"
                    }`}
                  >
                    {u.role}
                  </span>
                </td>
                <td className="px-4 py-3 text-[var(--muted)] text-xs">
                  {u.createdAt
                    ? new Date(u.createdAt).toLocaleDateString()
                    : "—"}
                </td>
                <td className="px-4 py-3">
                  {u.id !== me.id && (
                    <div className="flex gap-2">
                      {u.role !== "admin" ? (
                        <button
                          type="button"
                          onClick={() => changeRole(u.id, "admin")}
                          className="text-xs text-[var(--teal)] hover:underline"
                        >
                          Make admin
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => changeRole(u.id, "student")}
                          className="text-xs text-[var(--muted)] hover:underline"
                        >
                          Make student
                        </button>
                      )}
                    </div>
                  )}
                </td>
              </tr>
            ))}
            {users.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-[var(--muted)]">
                  No users yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-6 flex gap-2">
        <Button variant="secondary" onClick={() => router.push("/dashboard")}>
          Open student dashboard
        </Button>
        <Button
          variant="secondary"
          onClick={async () => {
            await signOut();
            router.push("/");
          }}
        >
          Sign out
        </Button>
      </div>
    </AppShell>
  );
}
