"use client";

import { useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Source_Serif_4 } from "next/font/google";
import { getSessionUser } from "@/lib/auth";
import PublicTheme from "@/components/PublicTheme";

const serif = Source_Serif_4({
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  style: ["normal", "italic"],
});

export default function LandingPage() {
  const router = useRouter();

  useEffect(() => {
    const u = getSessionUser();
    if (u) router.replace(u.role === "admin" ? "/admin" : "/dashboard");
  }, [router]);

  return (
    <div className="landing-shell relative h-[100dvh] overflow-hidden flex flex-col bg-[#2c3a47] text-[#f4efe6]">
      <PublicTheme />
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url('/library-bg.jpg')" }}
        aria-hidden
      />
      <div
        className="pointer-events-none absolute inset-0 bg-[#2c3a47]/55"
        aria-hidden
      />
      <div className="relative z-10 h-1 bg-[#0d9488] shrink-0" />

      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-5 py-4 text-center">
        <img
          src="/hero-mark.png"
          alt=""
          className="h-16 sm:h-20 w-auto"
        />
        <p
          className={`${serif.className} mt-1 mb-4 text-2xl sm:text-3xl font-semibold tracking-wide text-[#f4efe6]`}
        >
          Studious AI
        </p>

        <h1
          className={`${serif.className} text-[1.7rem] sm:text-4xl md:text-[2.6rem] font-semibold leading-[1.15] max-w-3xl text-[#f4efe6]`}
        >
          Your masterclass for every class.
        </h1>

        <p
          className={`${serif.className} mt-3 text-xl sm:text-2xl italic font-semibold text-[#2dd4bf]`}
        >
          Get Studious!
        </p>

        <p className="mt-4 max-w-lg text-[13px] sm:text-[15px] leading-relaxed text-[#f4efe6]/78">
          Studious AI turns the notes, PDFs, lectures, and textbooks you already
          have into one place to learn: comprehensive study notes, a lecture you
          can listen to, flash cards, and a quiz. Built for mastery of the
          course — not a shortcut around the work.
        </p>

        <div className="mt-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 w-full max-w-xs sm:max-w-none">
          <Link
            href="/signup"
            className="inline-flex items-center justify-center rounded-lg bg-[#f4efe6] text-[#2c3a47] w-full sm:w-44 px-6 py-3 text-sm font-semibold hover:bg-white transition-colors"
          >
            Create account
          </Link>
          <Link
            href="/login"
            className="inline-flex items-center justify-center rounded-lg border border-[#0d9488] text-[#2dd4bf] w-full sm:w-44 px-6 py-3 text-sm font-semibold hover:bg-[#0d9488] hover:text-white transition-colors"
          >
            Log In
          </Link>
        </div>
      </main>

      <footer className="relative z-10 px-6 py-3 text-center text-[11px] text-[#f4efe6]/40">
        Notes · Audio · Flash cards · Quiz · Your masterclass for every class.
      </footer>
    </div>
  );
}
