"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { signIn, getSessionUser } from "@/lib/auth";
import { getUserProfile } from "@/lib/profile";
import Button from "@/components/Button";
import PublicTheme from "@/components/PublicTheme";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const u = getSessionUser();
    if (u) router.replace(u.role === "admin" ? "/admin" : "/dashboard");
  }, [router]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const result = await signIn({ email, password });
    setLoading(false);
    if (result.error) {
      setError(result.error);
      return;
    }
    if (result.user?.role === "admin") {
      router.push("/admin");
      return;
    }
    const p = getUserProfile();
    if (!p.setupComplete) router.push("/profile");
    else if (p.role === "teacher" || p.edition === "teacher") router.push("/coming-soon");
    else router.push("/dashboard");
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#2c3a47] px-4">
      <PublicTheme />
      <div className="w-full max-w-[380px] bg-[var(--card)] rounded-2xl shadow-lg border border-[var(--border)] p-8">
        <div className="flex flex-col items-center mb-6">
          <Link href="/">
            <img src="/logo.png" alt="Studious AI" className="h-10 w-auto object-contain" />
          </Link>
          <p className="text-xs text-[var(--muted)] mt-1">Your masterclass for every class.</p>
        </div>

        <h2 className="text-center text-base font-semibold text-[var(--text)] mb-5">Log in</h2>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-medium text-[var(--muted)] mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5 text-sm outline-none focus:border-[var(--teal)] focus:ring-1 focus:ring-[var(--teal)]"
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--muted)] mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border border-[var(--border)] px-3 py-2.5 text-sm outline-none focus:border-[var(--teal)] focus:ring-1 focus:ring-[var(--teal)]"
              required
              autoComplete="current-password"
            />
          </div>

          {error && (
            <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full mt-2" disabled={loading}>
            {loading ? "Signing in…" : "Log in"}
          </Button>
        </form>

        <p className="text-center text-xs text-[var(--muted)] mt-3">
          <Link href="/forgot-password" className="text-[var(--teal)] hover:underline">
            Forgot password?
          </Link>
        </p>
        <p className="text-center text-xs text-[var(--muted)] mt-3">
          No account?{" "}
          <Link href="/signup" className="text-[var(--teal)] font-medium hover:underline">
            Create one
          </Link>
        </p>

        <p className="text-center text-xs text-[var(--muted)] mt-5">
          <Link href="/" className="hover:underline">
            ← Back to home
          </Link>
        </p>
      </div>
    </div>
  );
}
