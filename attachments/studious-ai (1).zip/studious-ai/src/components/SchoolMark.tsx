import type { SchoolBrand } from "@/lib/schools";

export default function SchoolMark({
  brand,
  logoUrl,
  size = 36,
}: {
  brand: SchoolBrand;
  logoUrl?: string;
  size?: number;
}) {
  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt={brand.name}
        style={{ width: size, height: size }}
        className="object-contain rounded"
      />
    );
  }
  return (
    <div
      className="rounded-md flex items-center justify-center text-white font-bold leading-none"
      style={{
        width: size,
        height: size,
        background: brand.primary,
        fontSize: brand.initials.length > 2 ? size * 0.28 : size * 0.34,
      }}
      aria-hidden
    >
      {brand.initials}
    </div>
  );
}
