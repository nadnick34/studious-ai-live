export default function InstituteMark() {
  return (
    <div className="pointer-events-none fixed bottom-3 right-3 z-50">
      <p className="institute-mark text-[10px] tracking-wide">
        Nickersonian Institute
      </p>
    </div>
  );
}
