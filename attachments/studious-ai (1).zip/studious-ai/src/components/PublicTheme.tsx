"use client";

import { useEffect } from "react";
import { clearBrandVars } from "@/lib/schools";

/** Landing, login, and signup always stay Studious teal — never school colors. */
export default function PublicTheme() {
  useEffect(() => {
    clearBrandVars();
  }, []);
  return null;
}
