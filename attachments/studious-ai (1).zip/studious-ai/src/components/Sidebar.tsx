"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { signOut } from "@/lib/auth";
import { getSavedBrand, type SavedBrand } from "@/lib/branding";
import { DEFAULT_BRAND } from "@/lib/schools";
import SchoolMark from "@/components/SchoolMark";
import { getUserProfile, initialsFromName, saveUserProfile, type EditionView } from "@/lib/profile";

export default function Sidebar({
  userName,
  isAdmin,
  open,
  onClose,
}: {
  userName?: string;
  isAdmin?: boolean;
  open?: boolean;
  onClose?: () => void;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [dark, setDark] = useState(false);
  const [brand, setBrand] = useState<SavedBrand>(DEFAULT_BRAND);
  const [edition, setEdition] = useState<EditionView>("student");
  const [role, setRole] = useState("student");
  const [avatar, setAvatar] = useState("");

  useEffect(() => {
    const stored = localStorage.getItem("studious-theme");
    const preferDark =
      stored === "dark" ||
      (!stored && window.matchMedia("(prefers-color-scheme: dark)").matches);
    setDark(preferDark);
    document.documentElement.classList.toggle("dark", preferDark);
    setBrand(getSavedBrand());
    const p = getUserProfile();
    setEdition(p.edition);
    setRole(p.role);
    setAvatar(p.avatarDataUrl || "");
    const onBrand = () => setBrand(getSavedBrand());
    const onProfile = () => {
      const next = getUserProfile();
      setEdition(next.edition);
      setRole(next.role);
      setAvatar(next.avatarDataUrl || "");
    };
    window.addEventListener("studious-brand-change", onBrand);
    window.addEventListener("studious-profile-change", onProfile);
    return () => {
      window.removeEventListener("studious-brand-change", onBrand);
      window.removeEventListener("studious-profile-change", onProfile);
    };
  }, []);

  function toggleDark() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("studious-theme", next ? "dark" : "light");
  }

  function setView(view: EditionView) {
    saveUserProfile({ edition: view });
    setEdition(view);
    onClose?.();
    if (view === "teacher") router.push("/coming-soon");
    else router.push("/dashboard");
  }

  async function handleLogout() {
    await signOut();
    router.push("/");
  }

  function itemClass(active: boolean) {
    return `flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
      active ? "bg-white/15 text-white" : "text-white/70 hover:bg-white/10 hover:text-white"
    }`;
  }

  const showToggle = role === "both" || role === "teacher";

  const content = (
    <>
      <div className="px-4 pt-5 pb-3 flex items-center justify-between">
        <Link href="/dashboard" className="flex flex-col items-start gap-3 min-w-0" onClick={onClose}>
          <span className="bg-[var(--card)] rounded-lg px-2 py-1.5 shadow-sm">
            <img src="/logo.png" alt="Studious AI" className="h-7 w-auto object-contain block" />
          </span>
          {brand.id !== "studious" && <SchoolMark brand={brand} logoUrl={brand.logoUrl} size={112} />}
        </Link>
        {onClose && (
          <button type="button" onClick={onClose} className="sm:hidden p-1.5 rounded-lg text-white/70 hover:bg-white/10" aria-label="Close menu">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      <nav className="flex-1 px-2.5 mt-2 space-y-0.5">
        <Link href="/dashboard" onClick={onClose} className={itemClass(pathname === "/dashboard" || pathname.startsWith("/class"))}>
          <svg className="w-4 h-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M4 19.5A2.5 2.5 0 016.5 17H20" />
            <path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" />
          </svg>
          My Classes
        </Link>
        <Link href="/archived" onClick={onClose} className={itemClass(pathname.startsWith("/archived"))}>
          <svg className="w-4 h-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
          </svg>
          Archived
        </Link>
        {isAdmin && (
          <Link href="/admin" onClick={onClose} className={itemClass(pathname.startsWith("/admin"))}>
            <svg className="w-4 h-4 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
            Admin
          </Link>
        )}
      </nav>

      <div className="px-4 py-4 border-t border-white/10 space-y-3">
        <button type="button" onClick={toggleDark} className="flex items-center gap-2 text-xs text-white/70 hover:text-white w-full">
          <span className="text-sm">{dark ? "☀️" : "🌙"}</span>
          {dark ? "Light mode" : "Night mode"}
        </button>

        <Link href="/profile" onClick={onClose} className="flex items-center" aria-label="Edit profile">
          <span className="h-[72px] w-[72px] rounded-full overflow-hidden bg-white/15 text-white text-xl font-semibold flex items-center justify-center ring-1 ring-white/20">
            {avatar ? (
              <img src={avatar} alt="" className="h-full w-full object-cover" />
            ) : (
              initialsFromName(userName)
            )}
          </span>
        </Link>

        {showToggle && (
          <div className="flex rounded-lg bg-white/10 p-0.5 text-[11px] font-medium">
            <button
              type="button"
              onClick={() => setView("student")}
              className={`flex-1 py-1.5 rounded-md ${edition === "student" ? "bg-white/20 text-white" : "text-white/60"}`}
            >
              Student
            </button>
            <button
              type="button"
              onClick={() => setView("teacher")}
              className={`flex-1 py-1.5 rounded-md ${edition === "teacher" ? "bg-white/20 text-white" : "text-white/60"}`}
            >
              Teacher
            </button>
          </div>
        )}

        <button onClick={handleLogout} className="text-xs text-white/60 hover:text-white transition-colors">
          Sign out
        </button>
      </div>
    </>
  );

  return (
    <>
      <aside className="w-56 bg-[var(--slate)] text-white flex-col shrink-0 h-screen sticky top-0 hidden sm:flex">
        {content}
      </aside>
      <div className={`fixed inset-0 z-40 sm:hidden transition ${open ? "pointer-events-auto" : "pointer-events-none"}`}>
        <div className={`absolute inset-0 bg-black/40 transition-opacity ${open ? "opacity-100" : "opacity-0"}`} onClick={onClose} />
        <aside className={`absolute left-0 top-0 h-full w-64 bg-[var(--slate)] text-white flex flex-col shadow-xl transition-transform duration-200 ${open ? "translate-x-0" : "-translate-x-full"}`}>
          {content}
        </aside>
      </div>
    </>
  );
}
