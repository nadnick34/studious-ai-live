"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Sidebar from "@/components/Sidebar";
import { getSessionUser } from "@/lib/auth";
import { getSavedBrand, hydrateBrand, type SavedBrand } from "@/lib/branding";
import { getUserProfile, initialsFromName } from "@/lib/profile";
import { pullProfilePrefs } from "@/lib/profileSync";
import SchoolMark from "@/components/SchoolMark";
import { DEFAULT_BRAND } from "@/lib/schools";

export default function AppShell({
  children,
  title,
  right,
}: {
  children: React.ReactNode;
  title?: string;
  right?: React.ReactNode;
}) {
  const router = useRouter();
  const [userName, setUserName] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [ready, setReady] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [brand, setBrand] = useState<SavedBrand>(DEFAULT_BRAND);
  const [avatar, setAvatar] = useState("");

  useEffect(() => {
    const user = getSessionUser();
    if (!user) {
      router.replace("/");
      return;
    }
    setUserName(user.name);
    setIsAdmin(user.role === "admin");
    hydrateBrand();
    setBrand(getSavedBrand());
    setAvatar(getUserProfile().avatarDataUrl || "");
    void pullProfilePrefs(user.id).then(() => {
      hydrateBrand();
      setBrand(getSavedBrand());
      setAvatar(getUserProfile().avatarDataUrl || "");
    });
    setReady(true);
  }, [router]);

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--bg)]">
        <div className="text-sm text-[var(--muted)]">Loading…</div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar
        userName={userName}
        isAdmin={isAdmin}
        open={menuOpen}
        onClose={() => setMenuOpen(false)}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 bg-[var(--card)] border-b border-[var(--border)] flex items-center justify-between gap-3 px-3 sm:px-6 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <button
              type="button"
              className="sm:hidden p-2 -ml-1 rounded-lg text-[var(--text)] hover:bg-slate-100"
              onClick={() => setMenuOpen(true)}
              aria-label="Open menu"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <Link href="/dashboard" className="sm:hidden shrink-0 flex items-center gap-2">
              <img src="/logo.png" alt="Studious AI" className="h-7 w-auto object-contain" />
              {brand.id !== "studious" && (
                <SchoolMark brand={brand} logoUrl={brand.logoUrl} size={28} />
              )}
            </Link>
            <h1 className="text-[15px] font-semibold text-[var(--text)] truncate hidden sm:block">
              {title || ""}
            </h1>
          </div>
          <div className="flex items-center gap-2 flex-wrap justify-end">
            <Link href="/profile" className="sm:hidden h-8 w-8 rounded-full overflow-hidden bg-[var(--teal)] text-white text-[10px] font-semibold flex items-center justify-center">
              {avatar ? <img src={avatar} alt="" className="h-full w-full object-cover" /> : initialsFromName(userName)}
            </Link>
            {right}
          </div>
        </header>
        {title && (
          <div className="sm:hidden px-4 pt-3">
            <h1 className="text-base font-semibold text-[var(--text)]">{title}</h1>
          </div>
        )}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
